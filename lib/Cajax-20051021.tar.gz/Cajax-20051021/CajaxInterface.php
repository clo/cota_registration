<?php
/**
 * Cajax Interface
 * 
 * This is a class for Ajax interface creation through CajaxEventHandler and CajaxFormHandler
 * A Cajax Interface have some CajaxEventHandler that will listen (using JavaScript) to user events on GUI,
 * and some CajaxFormHandler that will submit forms as XMLHTTPRequest
 * 
 * For bug reports (or donation :P), please contact pappacena@gmail.com
 * 
 * 
 * ******************* LICENCE *******************
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Lesser General Public License along 
 * with this library; if not, write to the Free Software Foundation, Inc., 59 
 * Temple Place, Suite 330, Boston, MA 02111-1307 USA 
 * ***********************************************
 * 
 * 
 * 
 * 
 * WARNING:
 * 	+	Keep in mind that this class makes a intensive use of JavaScript. This means that:
 * 			1- This script is tested in Mozilla Firefox and Internet Explorer 6. However, in some obscure browser, your system may NOT work!
 * 			2- A JavaScript sintax error or some other bizarre thing in other part of the page may stop your entire system, including Cajax. That's not my fault! :)
 * 			3- Your system will not work in Links, Lynx or W3M. Sorry. That's a price to pay... :P
 *
 * 
 * @example ./cajax_teste.php Simple way of using CajaxInterface, CajaxEventHandler and CajaxFormHandler
 * @author Thiago F. Pappacena
 * @license http://www.opensource.org/licenses/lgpl-license.php LGPL
 * @version 0.4.3
 */
class CajaxInterface {

	/**
	 * @access protected
	 * @since 0.1 - 30/06/2005
	 * @var	string	Helpfull Javascript for executing XMLHTTPRequest
	 */	
	var $jsInterface;

	/**
	 * @access protected
	 * @since 0.1 - 30/06/2005
	 * @var	bool	$jsInterface was already printed?
	 */		
	var $jsInterfaceDisplayed;
	
	/**
	 * @access protected
	 * @since 0.1 - 30/06/2005
	 * @var	array	Array of CajaxHandler
	 */
	var $Handler;
	
	/**
	 * @access protected
	 * @since 0.4.2 - 27/09/2005
	 * @var string The application document_root (deal with webservers diferences)
	 */
	var $documentRoot;
	
	
		  //****************************//
		 // INTERFACE CACHE ATTRIBUTES //
		//****************************//
	
	/**
	 * @access protected
	 * @since 0.4 - 08/08/2005
	 * @var	string	Cajax JavaScript include dir, relative to DOCUMENT_ROOT
	 */
	var $cacheDir;
	
	/**
	 * @access protected
	 * @since 0.4 - 08/08/2005
	 * @var	bool	Use cache or always recreates javascript output
	 */
	var $useCache;
	
	/**
	 * @access protected
	 * @since 0.4 - 08/08/2005
	 * @var	array	Files included (path relative to DOCUMENT_ROOT)
	 */
	var $jsIncludedFiles;
	
	
	
	/**
	 * Constructor
	 * 
	 * @access public
	 * @since 0.1 - 30/06/2005
	 * @param	void	void
	 */
	function CajaxInterface() {
		
		$this->Handler = array();
		$this->FormHandler = array();
		$this->jsInterfaceDisplayed = false;
		$this->jsInterface = "";
		$this->jsIncludedFiles = array();
		
		$this->setDocumentRoot();
		
		// Cache attributes
		$this->cacheDir = dirname($_SERVER['PHP_SELF'])."/cajaxJS/";
		$this->useCache = true;

	} // end :: CajaxInterface [constructor]
	

	/**
	 * Add an handler object to the CajaxInterface
	 * 
	 * @param	object	$Handler	A CajaxHandler (or subclass)
	 * @return	void
	 * @throws	CajaxInvalidHandlerException
	 */
	function addHandler(&$Handler) {
		if (!is_a($Handler, 'CajaxHandler'))
			$this->triggerError("\$Handler is not a valid CajaxHandler", E_USER_ERROR);

		$this->Handler[] = $Handler;

	} // end :: addHandler
	
	
	/**
	 * Call all CajaxHandler::handle() and outputs javascript
	 * 
	 * @access public
	 * @since 0.1 - 30/06/2005
	 * @param	bool	$showJavaScript	Display JavaScript interface [optional]
	 * @param	bool	$waitLoad		Wait until the document is loaded to execute javaScripts [optional]
	 * @return	void
	 */
	function handleAll($showJavaScript = false, $waitLoad = null) {
		
		foreach ($this->Handler as $k=>$v)	// Handle all events
			$v->handle();
		
		if ($showJavaScript) {				// Show JavaScript?
			
			if (is_null($waitLoad)) {		// Not forced to wait or not
				if ($this->usingCache())	// If using cache (and include files),
					$waitLoad = true;		// wait to load everything
				else						// else
					$waitLoad = false;		// try to eval while loading...
			}
				
			$this->displayJSInterface($waitLoad);	// And display functions to manipulate this events
			
		}
		
	} // end :: handleAll
	
	
	/**
	 * Obfuscate javascript code and make it a little harder to read
	 * 
	 * @static
	 * @access public
	 * @since 0.4 - 01/09/2005
	 * @param	string	$javascript	Javascript to be obfuscated
	 * @return	string	Bizzarre coding-style javascript
	 */
	function obfuscateJS($javaScript) {
		
		// remove comment lines and white spaces
		$javaScript = explode("\n", $javaScript);
		
		$buf = "";
		foreach ($javaScript as $i=>$v)
			if ( !($v = trim($v)) )							// Empty line
				continue;									// Try next line
			elseif ( strpos($v, "//") === 0 )				// Comment line
				continue;									// Try next line
			elseif ( ($pos = strpos($v, "//")) !== false )	// Has comment
				$buf .= trim( substr($v, 0, $pos) );		// Remove the comments
			else if ($v == 'else')							// 'else' line
				$buf .= $v. " ";							// Put a space after
			else											// Hole line is code
				$buf .= $v;									// Remove white spaces after and before it

		return $buf;
		
	} // end :: obfuscateJS
	
	
	/**
	 * Encode javascript to be used in a 'eval' function, escaping code and removing comments and empty lines
	 * 
	 * @static
	 * @access public
	 * @since 0.1 - 30/06/2005
	 * @param	string	$javaScript JavaScript to be encoded
	 * @return	string	Encoded javascript
	 */
	function encodeForEval($javaScript) {
		
		// Escape javascript contents to put into a javascript 'eval' function
		return CajaxInterface::obfuscateJS( addslashes($javaScript) );

	} // end :: encodeForEval
	
	
	/**
	 * Loads javascript $filename to the interface
	 * 
	 * This method will load a $file to your javascript Cajax interface
	 * 
	 * @access protected
	 * @since 0.4 - 08/08/2005
	 * @param	string	$file	Path to file to be loaded into interface
	 * @param	string	$subdir	Cache subdirectory to store cachefile [optional]
	 * @return	bool	Success
	 * @throws	CajaxInvalidCacheDir, CajaxNotWritableCacheDir
	 */
	function loadToInterface($file, $intoSubdir = "") {
		
		if ( $this->usingCache() ) {		// if using cache,
		
			// If it's not a valid writable dir
			if ( !is_dir("{$this->documentRoot}/{$this->cacheDir}") || !is_writable("{$this->documentRoot}/{$this->cacheDir}") ) {
				$errorMsg = 
				"CajaxInterface \$cacheDir ({$this->documentRoot}/{$this->cacheDir}) is not a valid directory or is not writable.<br/><br/>
				To avoid this message, set a correct path to a writable directory that will be used as cache for Cajax,<br/>
				or use Cajax->useCache(false), but keep in mind that using cache may improves Cajax performance<br/><br/>";
				$this->triggerError($errorMsg, E_USER_ERROR);
			}
			
			$fileName = basename($file);
			$fileDir = dirname($file);
			
			// Cache dir to be used
			$serverCacheDir = $this->documentRoot."/".$this->cacheDir."/{$intoSubdir}";
			
			if ( !is_dir($serverCacheDir) )				// If it's not a directory,
				mkdir($serverCacheDir, 0755);			// Lets create
			elseif ( !is_writable($serverCacheDir) )	// If is a directory, but I can't write
				$this->triggerError("Server cacheDir already exists and is not writable!", E_USER_ERROR);
				

			$serverCacheFile = "{$serverCacheDir}/{$fileName}";
			
			// If the original file is newer than cached or there's no cache
			if ( !file_exists($serverCacheFile) || (filemtime($serverCacheFile) < filemtime($file)) ) {
				
				$cacheFh = fopen($serverCacheFile, 'w+');								// Open a new cache file
				
				$jsString = file_get_contents($file). " Cajax.includedFiles[ Cajax.includedFiles.length ] = '$fileName';";	// The contents and a javascript instruction indicating to client-side Cajax that the file was already loaded 
				
				$jsString = CajaxInterface::obfuscateJS( $jsString );
				fwrite($cacheFh, $jsString);	// Puts file contents into cache
				fclose($cacheFh);
				
			}
			
			$this->jsIncludedFiles[] = strtr( "/{$this->cacheDir}/{$intoSubdir}/{$fileName}", array('//' => '/') );		// Cache cache file to be used as javascript include
			
		}
		else {								// Not using cache...
		
			$this->jsInterface .= file_get_contents($file);
			
		}
		
	} // end :: loadToInterface
	
	
	/**
	 * Print JavaScript interface (if not yet printed) and sets jsInterfaceDisplayed to true.
	 * 
	 * @access public
	 * @since 0.1 - 30/06/2005
	 * @param	bool	$waitLoad	Wait the hole document load to assign events?
	 * @return	void
	 */
	function displayJSInterface($waitLoad = true) {
		
		if ($this->interfaceDisplayed())	// Print again??
			return;							// no way!
					
		print $this->getJSInterface($waitLoad);
		
		$this->jsInterfaceDisplayed = true;
		
	} // end :: displayJSInterface
	
	
	/**
	 * Get JavaScript interface string.
	 * 
	 * @access public
	 * @since 0.1 - 30/06/2005
	 * @param	bool	$waitLoad	Wait the hole document load to assign events?
	 * @return	string	The javascript text
	 */
	function getJSInterface($waitLoad = true) {
		
		if ( !count($this->Handler) )
			$this->triggerError("There's no handle in Cajax! Why are you...? <br/>Ok... I'll give you the Javascript. That's a free world and a free software... but would be nice if you create a class to do what are you doing, than send it to community.<br/>(To disable this alert, use \"@\" before calling \$Cajax->getJSInterface())", E_USER_WARNING);
			
		if (!$waitLoad)
			$this->triggerError("Cajax is unstable using \$waitLoad = false in getJSInterface method", E_USER_WARNING);
		
		$JSToLoad = array();	// Javascript files that will need to be loaded to interface
		
		// Get all javascript generated by this class...
		$this->loadToInterface(CAJAX_ROOT.'/JS/cajax.js');
		
		// ... and by handlers
		$HandlerJavaScript = '';
		foreach ($this->Handler as $k=>$v) {
			
			$HandlerJavaScript .= $v->getJavaScriptHandler();
			$includedJS = $v->getIncludedJSFiles();
			foreach($includedJS as $k=>$v)
				if (!in_array($v, $JSToLoad))
					$JSToLoad[] = $v;
					
		}
		$HandlerJavaScript = CajaxInterface::encodeForEval( $HandlerJavaScript );

		// Load all javascripts include files to interface...		
		foreach($JSToLoad as $k=>$v)
			$this->loadToInterface($v);

		// ... than encode it
		$interfaceJavaScript = CajaxInterface::encodeForEval( $this->jsInterface );

		$js = "";

		// Show javascript.
		// Note: All this encoding is just to get hard to read javascript code from client-site... 
		// Why? This is a free software, but users don't have to know what you're using on server-side! :)
		// Obfuscating a little bit all this JavaScript may not expose so easily your estructure to a possible hacker...
		// Sending less text output (like comments and white lines) is nice to. Why send if user will never see this text?! Comments and white lines are overhead... :P
		
		// If you $waitLoad is set to true, the cajax interface will be loaded only after the document.load event.
		// otherwise, the script will try to evaluates javascript while page is being loaded.
		// Since version 0.2.2, Cajax will try to evaluate script until the document loads (or until 
		// the string evaluates as it should, what come first...).
		// The time between each retry is 500 ms (0.5 second)
		// Keep in mind that waiting document.onload is safest choice, avoiding some bizarre-unknown-obscure javascript errors.
		
		if ( !$waitLoad ) {
		
			if (count($this->jsIncludedFiles)) {						// If there's javascript files to include
				$tmp = array();
				foreach ($this->jsIncludedFiles as $k=>$v)				// Foreach file to include
					$tmp[] = basename($v);								// Copy the filename
				$jsFilesArray = "[\"". implode('", "', $tmp) ."\"]";	// String to create a javascript array

				// String to test if all needed include files where loaded				
				$testIncludedFiles = 
							"// Cajax javascript object or some some other include file not yet loaded
							if ( !Cajax || !Cajax.allFilesIncluded(cjxFilesToInclude) ) {
								setTimeout('cajaxLoadHandlers(\"'+ evalString +'\")', 500);	// try again soon
								return false;												// And don't eval it now
							}";
			}
			else {														// There's no javascript to include.
				$jsFilesArray = "new Array()";							// String to create a javascript empty array
			}
			
			$js .= CajaxInterface::encodeForEval(
				"	var cjxDocLoaded = false;					// Document not yet loaded
					var cjxFilesToInclude = {$jsFilesArray};	// Javascript include files

					// Try to evaluate evalString, receiving the number of failures before this call
					function cajaxLoadHandlers(evalString){

						// Try to eval
						try {
							if (!cjxDocLoaded)	// If document not yet loaded, try again on error
								retry = 1;
							else
								retry = 0;

							// Tests if all included files where included (if needed!). This PHP variable is being set some lines above, rigth before this string assignment 
							$testIncludedFiles

							eval(evalString);
						} catch (e) {			// If there's error
 
							if (retry)
								setTimeout('cajaxLoadHandlers(\"'+ evalString +'\")', 500);
							else
								alert('Error loading interface: '+ e.message);

						} // end :: catch

					} // end :: cajaxLoadHandlers

					eval(\"{$interfaceJavaScript}\");
					cajaxLoadHandlers(\"{$HandlerJavaScript}\");	// Try to eval javascript from event handler

					// When the document loads, set cjxDocLoaded as true (to stop trying to eval hendlers)
					addEvent(window, 'load', function(){cjxDocLoaded = true;});"
				);
				
		}
		else {	// Wait the document.load to eval... 
			
			$js .= CajaxInterface::encodeForEval(
					"function loadCajax(){ eval(\"{$interfaceJavaScript}\"); eval(\"{$HandlerJavaScript}\"); }
					if (window.addEventListener)
						window.addEventListener('load', loadCajax, true);
					else 
						window.attachEvent('onload', loadCajax);"
			);
						
		}
		
		$return = <<<END
		
			<!--
				CAJAX
				
				Part of this page's GUI was made using CajaxInterface and it's handlers
				Cajax is an open source PHP library for creating web interfaces reducing the postback need.
				
				This library was designed by Thiago F. Pappacena
				http://www.sourceforge.net/projects/cajax
			-->
			
END;
		
		// Return everything :P
		foreach($this->jsIncludedFiles as $k=>$v)
			$return .= "\t<script language=\"JavaScript\" type=\"text/javascript\" src=\"{$v}\"></script>\n";
		$return .= "\t<script language=\"JavaScript\" type=\"text/javascript\">eval(\"{$js}\");</script>";

		return $return;
		
	} // end :: getJSInterface
	
	
	/**
	 * Trigger an error in CajaxInterface
	 * 
	 * @access protected
	 * @since 0.4 - 08/08/2005
	 * @param	string	$msg	Error message
	 * @param	int		$level	Error level
	 * @return	void
	 */
	function triggerError($msg, $level = E_USER_WARNING) {
		trigger_error("<span style='color: red'><strong>Cajax Interface</strong></span>: ${msg}", $level);
	} // end :: triggerError
	
	
	/**
	 * Implementation of fnmatch to make the class work on non-Posix environment
	 * 
	 * For details about fnmatch, see PHP manual
	 * 
	 * @static
	 * @access public
	 * @since 0.4.2 - 27/09/2005
	 * @param	string	$pattern	String pattern (with wild chars)
	 * @param	string	$filename	File name
	 * @return	bool	Filename match the pattern?
	 * @see		http://www.php.net/manual/en/function.fnmatch.php
	 */
	function fnmatch( $pattern, $filename ) {
	
		$s = "";
		$count = strlen($pattern);
		for ($i = 0; $i < $count; $i++) {
			$c = $pattern{$i};
			if ($c =='?')
				$s .= '.'; // any character
			elseif ($c == '*')   
				$s .= '.*'; // 0 or more any characters   
			elseif ($c == '[' || $c == ']')
				$s .= $c;  // one of characters within []
			else
				$s .= '\\' . $c;
		}
		$s = '^' . $s . '$';
	
		//trim redundant ^ or $
		//eg ^.*\.txt$ matches exactly the same as \.txt$
		if (substr($s,0,3) == "^.*")
	 		$s = substr($s,3);
		if (substr($s,-3,3) == ".*$")
			$s = substr($s,0,-3);
		
		return ereg( $s, $filename);
		
	}

	
	/**
	 * Gets all Cajax{something}Handler file names recursivily from $dir
	 * 
	 * @access protected
	 * @since 0.4 - 12/08/2005
	 * @param	string	$dir	Directory where to start the search
	 * @return	array	Class file names
	 */
	function getAllHandlersFiles($dir) {
		
		if (!is_dir($dir))
			return array();
			
		$files = array();
		$dirs = array();

		foreach(glob("{$dir}/*", GLOB_NOSORT) as $k=>$v)		// Foreach item in directory,
			if (is_dir($v) && $v != '.' && $v != '..')			// If it's a subdirectory,
				$dirs[] = $v;									// Put in subdirectories list
			elseif ( CajaxInterface::fnmatch("*Cajax*Handler.class.php", $v) )	// Else, if it looks like an CajaxHander,
				$files[] = $v;									// Put in files list

		foreach($dirs as $k=>$v)												// Get Cajax handlers from subdirectory
			$files = array_merge($files, CajaxInterface::getAllHandlersFiles($v));	// Search inside this directory
			
		return $files;
		
	} // end :: getAllHandlersFiles
	
	
	/**
	 * Get examples from every subfolder of $dir
	 * 
	 * @access public
	 * @since 0.4 - 01/09/2005
	 * @param	string	$dir	Folder where to start the search
	 * @return	array	Examples files
	 */
	function getExamplesFiles($dir) {
		
		if (!is_dir($dir))
			return array();
			
		$files = array();
		foreach(glob("{$dir}/*", GLOB_NOSORT) as $k=>$v)
			if (is_dir($v))
				$files = array_merge( $files, CajaxInterface::getExamplesFiles($v) );
			elseif ( CajaxInterface::fnmatch("*.example.php", $v) )
				$files[] = $v;
				
		return $files;
		
	} // end :: getExamplesFiles
	
	
	
		  //*****************************//
		 //********** GETTERS **********//
		//*****************************//
		
	/**
	 * Gets path to Cajax javascript include files (relative to DOCUMENT_ROOT) 
	 * 
	 * @access public
	 * @since 0.4 - 08/08/2005
	 * @param	void	void
	 * @return	string	Javascript include dir
	 */
	function getCacheDir() {
		return $this->cacheDir;
	} // end :: getCacheDir
	
	
	/**
	 * Gets handlers in interface
	 * 
	 * @access public
	 * @since 0.4 - 08/08/2005
	 * @param	void	void
	 * @return array Handlers
	 */
	function & getHandlers() {
		return $this->Handler;
	} // end :: getHandlers

		
		  //*****************************//
		 //********** SETTERS **********//
		//*****************************//
	
	/**
	 * Gets path to Cajax javascript include files (relative to DOCUMENT_ROOT)
	 * 
	 * @access public
	 * @since 0.4 - 08/08/2005
	 * @param	string	$dir	The directory
	 * @return	void
	 */
	function setCacheDir($dir) {
		
		$dir = trim($dir);
		
		if ( strpos($dir, $this->documentRoot) === 0 )
			$dir = substr( $dir, strlen($this->documentRoot) );
		elseif ( strpos($dir, '/') === 0 )
			trigger_error("\$dir (${dir}) don't seems to be a relative path. cacheDir may be a path relative to your DOCUMENT_ROOT.", E_USER_WARNING);
		
		if ( !is_dir($this->documentRoot."/$dir") || !is_writable($this->documentRoot."/$dir") )
			trigger_error("\$dir (${dir}) is not a writable directory. Please, choose another directory or change the directory permissions.", E_USER_ERROR);
		
		while( strpos($dir, '//') !== false )
			$dir = str_replace("//", "/", $dir);
			
		$this->cacheDir = $dir;
		$this->useCache = true;
			
	} // end :: setCacheDir
	
	/**
	 * Sets CajaxInterface to use cache
	 * 
	 * @access public
	 * @since 0.4 - 08/08/2005
	 * @param	bool	$boolean	Use or not cache
	 * @return	void
	 */
	function useCache($boolean = true) {
		$this->useCache = $boolean;
	} // end :: useCache
	
	
	/**
	 * Define the application document_root
	 * 
	 * This function is meant to help making Cajax cross-plataform and
	 * relatively webserver independent. 
	 * Since Microsoft IIS don't define, by default, the _SERVER[DOCUMENT_ROOT]
	 * variable, here we make choice of what variable read to know witch directory 
	 * is our root (from where we can deal with cache).
	 * As IIS, other webservers might not define this variable. If you have problems
	 * using CajaxInterface in your webserver, please send a bug report to us 
	 * (including you phpinfo(), please)!
	 * 
	 * Especial thanks to Valdinei dos Santos (todebobeira@hotmail.com) for help debugging!
	 * 
	 * @access protected
	 * @since 0.4.2 - 27/09/2005
	 * @param	string	$documentRoot	The document_root string to be used in instance [optional]
	 * @return	void
	 */
	function setDocumentRoot( $documentRoot = "" ) {
		
		if ( strlen($documentRoot) ) {
			$this->documentRoot = $documentRoot;
			return;
		}
		
		// Default APACHE variable is defined?
		if ( isset($_SERVER['DOCUMENT_ROOT']) && trim($_SERVER['DOCUMENT_ROOT']) ) {
			$this->documentRoot = $_SERVER['DOCUMENT_ROOT'];
			return;
		}
		
		// $_SERVER['doc_root'] variable is defined?
		if ( isset($_SERVER['doc_root']) && trim($_SERVER['doc_root']) ) {
			
			$this->documentRoot = $_SERVER['doc_root'];
			return;
			
		}
		
		// $_SERVER['DOC_ROOT']? Is defined?
		if( isset($_SERVER['DOC_ROOT']) && trim($_SERVER['DOC_ROOT']) ) {
			
			$this->documentRoot = $_SERVER['DOC_ROOT'];
			return;
			
		}
		
		// Try to build the DOCUMENT_ROOT based on another informations
		if ( isset($_SERVER['PATH_TRANSLATED']) && trim($_SERVER['PATH_TRANSLATED']) ) {

			
			if ( isset($_SERVER['PHP_SELF']) && trim($_SERVER['PHP_SELF']) )
				$scriptName = $_SERVER['PHP_SELF'];
			elseif( isset($_SERVER['SCRIPT_NAME']) && trim($_SERVER['SCRIPT_NAME']) )
				$scriptName = $_SERVER['SCRIPT_NAME'];
			elseif( isset($_SERVER['PATH_INFO']) && trim($_SERVER['PATH_INFO']) )
				$scriptName = $_SERVER['PATH_INFO'];
			else
				$scriptName = "";	
			
			if ( $scriptName ) {
				
				while( strpos($scriptName, "//") !== false )
					$scriptName = str_replace("//", "/", $scriptName);
					
				$scriptNameLength = strlen($scriptName);
				$pathLength = $_SERVER['PATH_TRANSLATED'];
				$this->documentRoot = substr( $_SERVER['PATH_TRANSLATED'], 0, $pathLength - $scriptNameLength );
				return;
				
			}
			
		}
		
		// Nope... I don't know where is the root
		$msg =	"You have no DOCUMENT_ROOT defined.<br><br>\n".
				"DOCUMENT_ROOT is necessary to Cajax operations (mainly with cache).<br><br>\n".
				"Try to define DOCUMENT_ROOT environment variable or define \$_SERVER['DOCUMENT_ROOT'] before including CajaxInterface.php.";
		$this->triggerError($msg, E_USER_ERROR);
		return;
		
	}
	
	
		  //*****************************//
		 //********** TESTERS **********//
		//*****************************//
	
	/**
	 * Returns true if the JavaScript has already been sent to browser
	 * 
	 * @access public
	 * @since 0.1 - 01/07/2005
	 * @param	void	void
	 * @return	bool	Interface displayed
	 */
	function interfaceDisplayed() {
		
		return (bool) $this->jsInterfaceDisplayed;
		
	} // end :: interfaceDisplayed
	
		
	/**
	 * Tests if CajaxInterface is using cache
	 * 
	 * @access public
	 * @since 0.4 - 08/08/2005
	 * @param	void	void
	 * @return	bool	Using Cache? 
	 */
	function usingCache() {
		return (bool) $this->useCache;
	} // end :: usingCache
	
} // end :: class


// Some constants
define('CAJAX_ROOT', dirname(__FILE__));
define('CAJAX_HANDLERS_ROOT', CAJAX_ROOT.'/Handlers');


// Include all handlers class files
$files = CajaxInterface::getAllHandlersFiles(CAJAX_HANDLERS_ROOT);
foreach($files as $k=>$file)
	require_once($file);
?>