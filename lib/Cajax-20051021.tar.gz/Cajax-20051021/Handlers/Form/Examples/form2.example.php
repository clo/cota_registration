<?php

/*
 * A form handler example
 * 
 * This will use the default class behavior: submit the form and alert the server response
 */

if ( isset($_POST['formSent']) && $_POST['formSent'] ) {	// This is the action for the form...
	echo "Server say: ";
	sleep( rand(0, 200)/100 );	// Do nothing :)
	print_r($_POST);
	exit;
}

require("../../../CajaxInterface.php");	// Require CajaxInterface

$Cajax = new CajaxInterface();

// Create a new FormHandler
$FormHandler = new CajaxFormHandler('testForm2');

$Cajax->addHandler($FormHandler);		// Add the handler

$Cajax->handleAll();					// handle everything (if no parameter was passed, you'll need to call $Cajax->displayJSInterface())
?>
<html>
<head>

	<meta http-equiv="Content-Language" content="en" />
	<meta name="GENERATOR" content="PHPEclipse 1.0" />
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	
	<title>CajaxFormHandler test</title>
	
<? $Cajax->displayJSInterface(); ?>
	
	<style>
		.normal {
			font-face: arial;
			font-size: 11px;
			color: #3F3F3F;
		}
		
		.bold {
			font-face: arial;
			font-size: 11px;
			color: #3F3F3F;
			font-weight: bold;
		}
	</style>
</head>
<body bgcolor="#FFFFFF" text="#000000" link="#FF9966" vlink="#FF9966" alink="#FFCC99">


<div id="divMsg" class="bold" style="height: 30px;">

</div>

<div class="bold" style="position: relative; text-align: left;">
<form name="testForm2" id="testForm2" method="POST" onsubmit="document.getElementById('divMsg').innerHTML = 'Ok!';">
	
	
	Name: &nbsp;<input type="text" class="normal" name="name"><br/>
	Tel: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" class="normal" name="tel"><br/>
	Sex:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<select name="sex" class="normal">
					<option value="m">Male</option>
					<option value="f">Female</option>
				</select>
	<br/>
	
	<input type="hidden" name="formSent" value="1">
	<input type="checkbox" name="color[]" value="red"> Red<br/>
	<input type="checkbox" name="color[]" value="green"> Green<br/>
	<input type="checkbox" name="color[]" value="blue"> Blue<br><br/>
	
	<input type="radio" name="country" value="Brasil"> Brasil<br/>
	<input type="radio" name="country" value="Other"> Other<br/><br/>
	
	<select name="object[]" multiple>
		<option value="table">Table</option>
		<option value="phone">Telephone</option>
		<option value="computer">Computer</option>
	</select><br/><br/>
	
	<select name="smoking">
		<option value="no">No</option>
		<option value="yes">Yes</option>
	</select>
	
	<input type="text" name="testeBox" value="Send form, please!"><input type="submit" value="Send!">
	
</form>
</div>


</body>
</html>
  