<?php

/*
 * A form handler example
 * 
 * This example will submit the form thought XMLHttpRequest and insert the response from server
 * inside the div "formResult".
 */

if ( isset($_POST['formSent']) && $_POST['formSent'] ) {	// This is the action for the form...
	echo "<pre>Server say: ";
	print_r($_POST);
	echo "</pre>";
	exit;
}

require("../../../CajaxInterface.php");	// Require CajaxInterface

$Cajax = new CajaxInterface();

// Create a new FormHandler
$FormHandler = new CajaxFormHandler('testForm', 'function (responseString) { document.getElementById("formResult").innerHTML = responseString; }');

$Cajax->addHandler($FormHandler);		// Add the handler

$Cajax->handleAll();					// handle everything (if no parameter was passed, you'll need to call $Cajax->displayJSInterface())
?>
<html>
<head>

	<meta http-equiv="Content-Language" content="en" />
	<meta name="GENERATOR" content="PHPEclipse 1.0" />
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	
	<title>CajaxFormHandler test</title>
	
<? $Cajax->displayJSInterface(); ?>
	
	<style>
		.normal {
			font-face: arial;
			font-size: 11px;
			color: #3F3F3F;
		}
		
		.bold {
			font-face: arial;
			font-size: 11px;
			color: #3F3F3F;
			font-weight: bold;
		}
	</style>
</head>
<body bgcolor="#FFFFFF" text="#000000" link="#FF9966" vlink="#FF9966" alink="#FFCC99">


<div id="formResult">

</div>

<div class="bold" style="position: relative; top: 30px; text-align: left;">
<form name="testForm" id="testForm" method="POST">
	
	
	Name: &nbsp;<input type="text" class="normal" name="name"><br/>
	Tel: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" class="normal" name="tel"><br/>
	Sex:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<select name="sex" class="normal">
					<option value="m">Male</option>
					<option value="f">Female</option>
				</select>
	<br/>
	
	<input type="hidden" name="formSent" value="1">
	<input type="checkbox" name="color[]" value="red" class="normal"> Red<br/>
	<input type="checkbox" name="color[]" value="green" class="normal"> Green<br/>
	<input type="checkbox" name="color[]" value="blue" class="normal"> Blue<br><br/>
	
	<input type="radio" name="country" value="Brasil" class="normal"> Brasil<br/>
	<input type="radio" name="country" value="Other" class="normal"> Other<br/><br/>
	
	<select name="object[]" multiple class="normal">
		<option value="table">Table</option>
		<option value="phone">Telephone</option>
		<option value="computer">Computer</option>
	</select><br/><br/>
	
	<select name="smoking" class="normal">
		<option value="no">No</option>
		<option value="yes">Yes</option>
	</select>
	
	<input type="text" name="testeBox" value="Send form, please!" class="normal"><input type="submit" value="Send!" class="normal">
	
</form>
</div>


</body>
</html>
  