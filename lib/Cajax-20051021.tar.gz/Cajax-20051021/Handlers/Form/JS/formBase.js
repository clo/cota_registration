// Form handler exception object
function RefFrmExcp(){
	msg = 'document.getElementById ReferenceError on form handler';
	this.message=msg; this.name=msg;
}

function submitForm(form, returnFunction){
	param = "CajaxCall=1";		// Flag to indicate "call from Cajax"

	// Creates 'param' using form elements and values (what would be passed if sending though a syncronous request)
	for(i=0 ; i<form.elements.length ; i++){
		e = form.elements[i];
		if (e.type == 'select'){
			param += "&" + e.name +"="+ escape(e[ e.selectedIndex ].value);
		}
		else if (e.type == 'select-multiple'){
			for (k=0 ; k<e.length ; k++)
				if (e[k].selected)
					param += "&" + e.name +"="+ escape(e[k].value);
		}
		else if (e.type == 'radio'){
			if (e.checked)
				param += "&" + e.name +"="+ escape(e.value);
		}
		else if (e.type == 'checkbox'){
			if (e.checked)
				param += "&" + e.name +"="+ escape(e.value);
		}
		else {
			param += "&" + e.name +"="+ escape(e.value);
		}
	} // end :: for

	form.method = form.method? form.method : 'GET';				// Default submit method: GET
	Cajax.doRequest(form.action, param, form.method, returnFunction);	// Do the request!
}