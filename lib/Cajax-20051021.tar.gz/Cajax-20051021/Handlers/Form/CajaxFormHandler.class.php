<?php
/**
 * Cajax Form Handler
 * 
 * Redirects a HTML form to a XMLHttpRequest using CajaxInterface
 * This classes needs to be used with CajaxInterface, that is included in another file.
 * 
 * For bug reports (or donation :P), please contact pappacena@gmail.com
 * 
 * 
 * ******************* LICENCE *******************
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Lesser General Public License along 
 * with this library; if not, write to the Free Software Foundation, Inc., 59 
 * Temple Place, Suite 330, Boston, MA 02111-1307 USA 
 * ***********************************************
 * 
 * 
 * 
 * The default behavior is to submit the form and alert the output returned by server.
 * To change this behavior, you can define your own $returnFunctionName javascript functions.
 *
 * $returnFunctionName
 *		Here you will get as unique parameter the server response to your submit.
 *		Exemple:
 *		<script language="javascript">
 * 			function getReturnedSubmit(text) {
 *				document.getElementById('form_answer').innerHTML = text;
 *			} 
 *		</script>
 *
 *  
 * @author Thiago F. Pappacena
 * @license http://www.opensource.org/licenses/lgpl-license.php LGPL
 * @example	Examples/form1.example.php	A form handler writing server output to a div
 * @example	Examples/form2.example.php	A default-behavior form handler
 * @see	CajaxInterface
 * @version 0.3
 */
class CajaxFormHandler extends CajaxHandler {
	
	/**
	 * @access protected
	 * @since 0.1 - 04/07/2005
	 * @var	string	HTML form ID
	 */
	var $formName;
	
	/**
	 * @access protected
	 * @since 0.1 - 04/07/2005
	 * @var	string	JavaScript function that will receive returned data
	 */
	var $returnFunctionName;

	
	/**
	 * Constructor
	 * 
	 * @access public
	 * @since 0.1 - 04/07/2005
	 * @param	string	$formName			Form ID
	 * @param	string	$returnFunctionname	JavaScript function that will receive the output of the sent form [optional]
	 */
	function CajaxFormHandler($formName, $returnFunctionName = "") {
		parent::CajaxHandler();
		
		$this->formName = $formName;
		$this->javaScriptHandler = '';
		$this->returnFunctionName = $returnFunctionName;
		
		$this->includedJSFiles = array(dirname(__FILE__).'/JS/formBase.js');
		
		$this->handled = false;
		
	} // end :: CajaxFormHandler [constructor]
	
	
	/**
	 * Prepare client side scripts setting $this->javaScriptHandler
	 * 
	 * @access public
	 * @since 0.1 - 04/07/2005
	 * @param	void	void
	 * @return	void
	 */
	function prepareClientSide() {
		
		$this->javaScriptHandler = "";
		
		if ( !strlen(trim($this->returnFunctionName)) ) {	// If there's no user defined return function, create a default on
			$this->returnFunctionName = uniqid('cjxfh_');
			$this->javaScriptHandler .= "function {$this->returnFunctionName}(returnText){alert(returnText);}";
		}
		
		$this->javaScriptHandler .= 
		"	// If document.getElementById('this->formName') not yet loaded, throws a referenceError exceptions
			if ( (frm = cjxElem('{$this->formName}')) == null ) throw new RefFrmExcp();
	
			// Tests if there's another onsubmit function defined to form
			eval('fs_{$this->formName}='+frm.onsubmit);					// Gets the 'function submit' from the form and 'eval' it
			frm.onsubmit = function (){
						if (fs_{$this->formName} != undefined){			// If there's a function defined, use it before sending the form
							r = fs_{$this->formName}();					// Execut the original 'onsubmit'
							if (r != undefined && !r) return false;		// If there was a return value and it evaluates to false, return
						}
						submitForm(this, {$this->returnFunctionName});
						return false;									// and don't send it again. :P
					};";
		
	} // end :: prepareClientSide





		  //*****************************//
		 //********** GETTERS **********//
		//*****************************//
	
	/**
	 * Returns the handled form name
	 * 
	 * @access public
	 * @since 0.1 - 04/07/2005
	 * @param	void	void
	 * @return	string	Form name
	 */
	function getFormName() {
		return $this->formName;
	} // end :: getFormName
	
	
	/**
	 * Returns the javascript function name that will be called on server response
	 * 
	 * @access public
	 * @since 0.1 - 04/07/2005
	 * @param	void	void
	 * @return	string	JavaScript function name
	 */
	function getReturnFunctionName() {
		return $this->returnFunctionName;
	} // end :: getReturnFunctionName
	
} // end :: class
?>