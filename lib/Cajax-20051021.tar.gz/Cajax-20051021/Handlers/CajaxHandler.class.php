<?php
/**
 * Abstract class to guide Cajax*Handler creation
 * 
 * ******************* LICENCE *******************
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Lesser General Public License along 
 * with this library; if not, write to the Free Software Foundation, Inc., 59 
 * Temple Place, Suite 330, Boston, MA 02111-1307 USA 
 * ***********************************************
 * 
 * @abstract
 * @author Thiago F. Pappacena
 * @license http://www.opensource.org/licenses/lgpl-license.php LGPL
 * @see CajaxInterface
 * @version 0.2
 */
/* abstract */ class CajaxHandler {
	
	/**
	 * @access protected
	 * @since 0.1 - 12/08/2005
	 * @var	array	Javascript files to be included
	 */
	var $includedJSFiles;
	
	/**
	 * @access protected
	 * @since 0.1 - 12/08/2005
	 * @var	string	Javascript to be sent to client-side
	 */
	var $javaScriptHandler;
	
	/**
	 * @access protected
	 * @since 0.1 - 01/07/2005
	 * @var	bool	Define if this event handler is already handled by client-side JavaScript
	 */
	var $handled;
	
	
	/**
	 * Constructor
	 * 
	 * @since 0.1 - 12/08/2005
	 * @param	void	void
	 */
	function CajaxHandler() {
		$this->includedJSFiles = array();
		$this->javaScriptHandler = "";
		$this->handled = false;
	}
	
	
	/**
	 * Prepare client side scripts. In subclasses implementation, here you will set $this->javaScriptHandler
	 * 
	 * @abstract
	 * @access public
	 * @since 0.1 - 04/07/2005
	 * @param	void	void
	 * @return	void
	 */
	function prepareClientSide() {
		/* Abstract
		 * 
		 * Some code...
		 * Than:
		 * $this->javaScriptHandler .= "some javascript";
		 */
	} // end :: prepareClientSide
	
	
	/**
	 * Handle the handler :)
	 * This will be called on CajaxInterface::handleAll();
	 * If you redefine this method in your subclass, please call parent::handle()
	 * 
	 * @abstract
	 * @access public
	 * @since 0.1 - 12/08/2005
	 * @param	void	void
	 * @return	void
	 * @throws	CajaxHandlerAlreadyHandled
	 */
	function handle() {
		if ($this->isHandled())
			$this->triggerError('You cannot handle a CajaxHandler two times!', E_USER_ERROR);
		$this->handled = true;
	} // end :: handle
	
	
	/**
	 * Trigger an error in CajaxHandler
	 * 
	 * @access protected
	 * @since 0.1 - 08/08/2005
	 * @param	string	$msg	Error message
	 * @param	int		$level	Error level
	 * @return	void
	 */
	function triggerError($msg, $level = E_USER_WARNING) {
		$className = get_class($this);
		trigger_error("<b>$className</b>: ${msg}", $level);
	} // end :: triggerError
	
	
	
	/**
	 * Convert a string like class::method or object->method to a callback function info array
	 * 
	 * if $function is a method, converToCallbackInfo will return an array with the fallowing indexes:
	 * 	object		-> A reference to object (or a string, if static call using "::" operator)
	 * 	objectName	-> The variable name used to hold object
	 * 	method 		-> Object's method requested
	 * 	static		-> If it's a static call (using "::" operator)
	 * 
	 * 
	 * @access public
	 * @since 0.2 - 30/09/2005
	 * @param	string		$function	The string representing the call
	 * @return	callback	Callback function/method callable by call_user_func(_array)
	 */
	function & convertToCallbackInfo( $function ) {
	 	
	 	if ( is_callable($function) )
	 		return $function;
	 	
	 	if (($obj = strpos($function, '->')) || ($class = strpos($function, '::'))) {			// Has '->' operand (or '::'). It's an object method
			
			if ($obj) {
				
				$parm = explode('->', $function);
				$object = str_replace('$', '', $parm[0]);
				$method = $parm[1];
				
				// Here, we test if it's an object array (like $Object[] = new Object).
				// If so, we can't just get $GLOBALS[exploded[0]], since it will be something like
				// $GLOBALS['Object[0]']. We need to separate the name before the brackets and
				// the brackets and get $GLOBALS['Object'][0]
				if ( $posBracket = strpos($object, '[') ) {		// It's an object array
					$arrayName = substr( $object, 0, $posBracket );
					$arrayIndexes = trim( substr( $object, strpos($object, '[') ) );
					eval("\$objectReference = &\$GLOBALS['$arrayName']{$arrayIndexes};");
				}
				else {
					$objectReference = &$GLOBALS[$object];
				}

				return array( 'object'=>&$objectReference, 'objectName'=>$object, 'method'=>$method, 'static'=>0 );
				
			}
			elseif ($class) {
				
				$parm = explode('::', $function);
				$object = str_replace('$', '', $parm[0]);
				$method = $parm[1];
				$className = get_class(&$GLOBALS[$object]);
				
				return array( 'object'=>$object, 'method'=>$method, 'static'=>1 );
				
			}

		}
		else {												// There's no '->'. Handle as a function call
			return $function;
		}
		
	} // end :: convertToCallbackFunction
	 
	 
	/**
	 * Converte a callback array generated by convertToCallbackInfo to a callback (something callable by call_user_func)
	 * 
	 * @access public
	 * @since 0.2 - 30/09/2005
	 * @param	array	$callbackInfo	A string for function or an array as returned by self::convertToCallbackInfo()
	 * @return	callback	A callback
	 */
	function & callbackInfoToCallback( $callbackInfo ) {
	 	
	 	if ( is_array($callbackInfo) )	// Handling a method
			return array ( $callbackInfo['object'], $callbackInfo['method'] );
		else
			return $callbackInfo;
		
	}
	 
	 
	/**
	 * Returns the string used to create a callback info array
	 * 
	 * ex.: 
	 * 	callbackInfoToString( array( 'object'=>$object, 'method'=>$method, 'static'=>1 ) )
	 * 	// would return "object::method"
	 * 
	 * @param	array $callback Callback info array, like those ones generated by convertToCallbackInfo
	 * @return string String representation for $callback
	 */
	 function callbackInfoToString( $callback ) {
	 	
		if ( is_array($callback) ) {
			if ( is_string($callback['object']) )
				return "{$callback['object']}::{$callback['method']}";
			else 
				return "{$callback['objectName']}->{$callback['method']}";
		}
		else
			return $callback;
			
	 } // fim :: callbackInfoToString
	
		  //*****************************//
		 //********** TESTERS **********//
		//*****************************//
	
	/**
	 * Return true if the object is already listening to a call. False otherwise.
	 * 
	 * @access public
	 * @since 0.1 - 01/07/2005
	 * @param	void	void
	 * @return	bool	Is handled
	 */
	function isHandled() {
		return (bool) $this->handled;
	} // end :: isHandled


	
		  //*****************************//
		 //********** GETTERS **********//
		//*****************************//
	
	/**
	 * Returns the javascript handler
	 * 
	 * @access public
	 * @since 0.1 - 04/07/2005
	 * @param	void	void
	 * @return	string	JavaScript handler
	 */
	function getJavaScriptHandler() {
		$this->prepareClientSide();
		return $this->javaScriptHandler;
	} // end :: getJavaScriptHandler
	
	
	/**
	 * Returns javascript filenames to be loaded to CajaxInterface
	 * 
	 * @access public
	 * @since 0.1.2 - 12/08/2005
	 * @param	void	void
	 * @return	array	Javascript files
	 */
	function getIncludedJSFiles() {
		return $this->includedJSFiles;
	} // end :: getIncludedJSFiles
	
} // end :: class
?>