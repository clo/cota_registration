<?php
/**
 * Cajax Event Handler
 * 
 * Uses JavaScript to create a interface between server-side PHP procedures call and client-side GUI
 * This classes needs to be used with CajaxInterface, that is included in another file.
 * 
 * For bug reports (or donation :P), please contact pappacena@gmail.com
 * 
 * 
 * ******************* LICENCE *******************
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Lesser General Public License along 
 * with this library; if not, write to the Free Software Foundation, Inc., 59 
 * Temple Place, Suite 330, Boston, MA 02111-1307 USA 
 * ***********************************************
 * 
 * 
 * 
 * If no javaScript function is defined to act on defined event, Cajax Event Handler will
 * create default agents that will execute server-side function or method and alert it's
 * output. To change this default behavior, create JavaScript functions and associate the functions names
 * to jsFirerFunctionName and jsReturnFunctionName attributes. 
 * 
 * $jsFirerFunctionName will be called on event trigger. There, you'll need to call the object.Cajax.{event}() method,
 *  passing server-side function/method parameters. Change "{onevent}" by the event that will calls that action
 * 	(i.e, object.Cajax.onclick() or object.Cajax.onmouseover()).
 *
 * $jsReturnFunctionName will be called when server complete to request. This function will receive as unique parameter
 * the entire text printed/returned by function or method called. Inside it, you can manipulate this data at will. :)
 * 
 * 	Exemple: if you want to call $basket->clear() on button click and you
 * 		wanna ask for the user before the action, do something like:
 * 
 * 			In PHP, create the EventHandler and the CajaxInterface, then start the handler
 * 			<code>
 * 			<?php
 * 			$Cajax = new CajaxInterface();
 * 			$Cajax->addEventHandler( new CajaxEventHandler('button_clear_id', 'onclick', '$basket->clear', 'basketClear', 'serverAnswer') );
 *			$Cajax->handleAll();
 *			?>
 *
 *				<!------ SOME HTML, SUCH AS THE BUTTONS, ETC. ------>
 *
 *			<? $Cajax->displayJSInterface(); // Show javascript ?>
 * 			<script language="javascript">
 * 				function basketClear() {
 * 					if (confirm('Really wanna clear?')) {
 *						elem = document.getElementById('button_clear_id');
 *						elem.Cajax.onclick('all'); // Call server side function passing as parameter the string 'all'
 *						// and tell to javascript that you wanna receive the server-side answer in the function named "serverAnswer"
 *					}
 * 				}
 * 
 * 				// This function will be called when server complete the request
 * 				// the parameter "answer" will be the string returned by the request
 * 				function serverAnswer(answer) {
 * 					if (answer) {
 * 						alert('Ok. All clean! :P');
 * 						// Refresh some div contents or other presentation things
 * 					}
 * 					else {
 * 						alert('Error! Try again!');
 * 					}
 * 				}
 * 			</script>
 * 			</code>
 * 			
 * 
 * 
 * ERROR:
 * 	+	To execute procedures or methods through XMLHTTPRequest, Cajax will execute the entire PHP script again until you call
 * 		$Cajax->handleAll(), that will tell all Cajax interfaced CajaxEventHandler to listen for his calls.
 * 		This call is done sending a POST requisition to the script using the interface, passing 
 * 		CajaxEventHandler_function and CajaxEventHandler_parameters parameters. So, NEVER pass $_POST['CajaxEventHandler_function']
 * 		to your page, unless you know what are you doing (or, of course, you're doing a XMLHTTPRequest)
 * 
 * ******************************************************************************************************
 * 
 * 
 * @author Thiago F. Pappacena
 * @license http://www.opensource.org/licenses/lgpl-license.php LGPL
 * @see CajaxInterface
 * @version 0.2.3
 */
class CajaxEventHandler extends CajaxHandler {
	
	/**
	 * @access protected
	 * @since 0.1 - 01/07/2005
	 * @var	string	Event on $clientSideObjectName to be handled
	 */
	var $onEvent;
	
	/**
	 * @access protected
	 * @since 0.1 - 01/07/2005
	 * @var	string	Object that will be listened for the $onEvent
	 */
	var $clientSideObjectName;
	
	/**
	 * @access protected
	 * @since 0.1 - 01/07/2005
	 * @var	string	Server-side function name
	 */
	var $serverSideFunction;
	
	/**
	 * @access protected
	 * @since 0.1 - 01/07/2005
	 * @var	array	Array of parameters to be used on server side call. This array will be passed BEFORE the client side parameters
	 */
	var $serverSideParameters;
	
	/**
	 * @access protected
	 * @since 0.1 - 01/07/2005
	 * @var	string	FirerFunction name
	 */
	var $jsFirerFunctionName;
	
	/**
	 * @access protected
	 * @since 0.1 - 01/07/2005
	 * @var	string	ReturnFunction name
	 */
	var $jsReturnFunctionName;
	
	/**
	 * @access protected
	 * @since 0.1 - 01/07/2005
	 * @var	bool	Javascript already sent to client-side?
	 */
	var $javaScriptHandlerPrinted;
	
	
	/**
	 * Constructor
	 * 
	 * @access public
	 * @since 0.1 - 01/07/2005
	 * @param	string	$clientSideObjectName	Object name (or ID) that will listen event
	 * @param	string	$onEvent				Event to fire the PHP function
	 * @param	string	$serverSideFunction		PHP function (or method) name to be called when event occur
	 * @param	string	$jsReturnFunctionName	User defined JavaScript function to be called when server respond to a XMLHTTPRequest [optional]
	 * @param	string	$jsFirerFunctionName	User defined JavaScript function to be called when evend occur [optional]
	 * @param	array	$serverSideParameters	Parameters array to be passed to server side function call. This may be database handler, file handler, etc. Or event a simple string created on serverside [optional]
	 */
	function CajaxEventHandler($clientSideObjectName, $onEvent, $serverSideFunction, $jsReturnFunctionName = '', $jsFirerFunctionName = '', $serverSideParameters = null) {
		parent::CajaxHandler();
		
		$this->jsReturnFunctionName = $jsReturnFunctionName;
		$this->jsFirerFunctionName = $jsFirerFunctionName;
		$this->javaScriptHandler = '';
		$this->javaScriptHandlerPrinted = false;
		$this->handled = false;
		
		$this->includedJSFiles = array(dirname(__FILE__).'/JS/eventBase.js');
		
		$onEvent = strtolower(trim($onEvent));
		$this->onEvent = (strpos($onEvent, 'on') === false)? "on{$onEvent}" : $onEvent;
		$this->clientSideObjectName = $clientSideObjectName;
		
		if (is_array($serverSideParameters) && count($serverSideParameters))
			$this->serverSideParameters = $serverSideParameters;
		else
			$this->serverSideParameters = array();
			
		$this->serverSideFunction = CajaxEventHandler::convertToCallbackInfo( $serverSideFunction );
				
	} // end :: CajaxEventHandler [constructor]
	
	
	
	
	/**
	 * Prepare javascript for the client side handling setting $this->javaScriptHandler
	 * 
	 * @access protected
	 * @since 0.1 - 01/07/2005
	 * @param	void	void
	 * @return	void
	 */
	function prepareClientSide() {

		$functionName = $this->getClientSideFunctionName();
		
		$onEvent = $this->onEvent;
		$event = substr($this->onEvent, 2);

		$this->javaScriptHandler = "";
		
		// if there's no user defined return function, create a default one
		if ( !strlen(trim($this->jsReturnFunctionName)) )
			$this->jsReturnFunctionName = "function (responseText){ alert(responseText); }";
		
		// if there's no user defined trigger function, create a default one
		if ( !strlen(trim($this->jsFirerFunctionName)) )
			$this->jsFirerFunctionName = "function (){ cjxElem('{$this->clientSideObjectName}').Cajax.{$onEvent}(); }";
		
		// Associate event to the object
		$this->javaScriptHandler .= 
		"	// If element is null, throws an exception
			if ( (elm = cjxElem('{$this->clientSideObjectName}')) == null ) throw new RefEvExcp();

			addEvent(elm, '{$event}', {$this->jsFirerFunctionName});

			// Methods pointers
			if (!elm.Cajax)
				elm.Cajax = new Object;
			elm.Cajax.{$onEvent} = 	function () { 
										args = this.{$onEvent}.arguments;
										args[ args.length ] = {$this->jsReturnFunctionName};	// Pass, as last argument, the javascript return function
										args.length++; 
										callServerSide('{$functionName}', args);				// Call the server side 
									};";
		
	} // end :: prepareClientSide
	
	
	
	/**
	 * Execute the handled server side function passing $parameters
	 * 
	 * @access protected
	 * @since 0.1 - 01/07/2005
	 * @param	array	$parameters	Array of parameters to pass do handled function
	 * @return	void
	 */
	function executeServerSideFunction($parameters) {
				
		$callback = CajaxEventHandler::callbackInfoToCallback( $this->serverSideFunction );

		if ( is_array($parameters) )
			$parameters = array_merge($this->serverSideParameters, $parameters);
		else
			$parameters = $this->serverSideParameters;
		print call_user_func_array($callback, $parameters);
		exit;
		
	} // end :: executeServerSideFunction
	
	
	/**
	 * Handle the configured server side function
	 * 
	 * @access public
	 * @since 0.1 - 01/07/2005
	 * @param	void	void
	 * @return	void
	 * @throws	CajaxHandlerAlreadyHandled
	 */
	function handle() {
		
		parent::handle();
			
		if (headers_sent())		// Data already sent? It may not be what we want!
			$this->triggerError("Output data already sent to client. The Event Handler may not work as desired.<br/>To avoid it, use handle() method before sending output to client machine<br/>" , E_USER_WARNING);
		
			// *** Trying to call my handled function from XMLHTTPRequest? *** //
		if ( isset($_POST['CajaxEventHandler_function']) ) {
			
			// Hum... Calling a method and I'm handling a method!
			if ( $this->handlingMethod() ) {
				
				if ( strpos($_POST['CajaxEventHandler_function'], '::') ) {				// Trying to call a static method?
				
					$exploded = explode('::', $_POST['CajaxEventHandler_function']);	// Determine class name and method name
					$staticCall = true;													// Sets $staticCall flag to true
					
				}
				elseif ( strpos($_POST['CajaxEventHandler_function'], '->') ) {			// Not trying to call a static method
				
					$exploded = explode('->', $_POST['CajaxEventHandler_function']);	// Determine the method name...
					//$exploded[0] = &$GLOBALS[$exploded[0]];								// ... and the object
					
					// Object array need to treat the string to get GLOBALS 
					if ( $posBracket = strpos($exploded[0], '[') ) {	// It's an object array
						$arrayName = substr( $exploded[0], 0, $posBracket );
						$arrayIndexes = trim( substr( $exploded[0], strpos($exploded[0], '[') ) );
						eval("\$exploded[0] = &\$GLOBALS['$arrayName']{$arrayIndexes};");
					}
					else {
						$exploded[0] = &$GLOBALS[$exploded[0]];
					}

					$staticCall = false;												// Sets flag to false
					
				}
				

				// They're calling my handled method?
				if ( $exploded[0] == $this->serverSideFunction['object'] && $exploded[1] == $this->serverSideFunction['method'] )
					$this->executeServerSideFunction(
									isset($_POST['CajaxEventHandler_parameters'])?
										$_POST['CajaxEventHandler_parameters'] : array()
								);

			}
			// I'm not handling a method and they are calling a function.
			elseif (!strpos($_POST['CajaxEventHandler_function'], '::') && !strpos($_POST['CajaxEventHandler_function'], '->') && !$this->handlingMethod()) {

				if ($_POST['CajaxEventHandler_function'] == $this->serverSideFunction && is_callable($_POST['CajaxEventHandler_function']))	// hey! They are calling my handled function!
					$this->executeServerSideFunction(
										isset($_POST['CajaxEventHandler_parameters'])? 
												$_POST['CajaxEventHandler_parameters'] : array()
									);

			}
			
		}
			// *** END :: Trying to call my function from XMLHTTPRequest? *** //
		
	} // end :: handle
	

	/**
	 * Print the JavaScript functions and JavaScript event handlers
	 * 
	 * @access public
	 * @since 0.1 - 01/07/2005
	 * @param	void	void
	 * @return	void
	 */
	function printJavaScriptHandler() {

		print $this->getJavaScriptHandler();
		
	} // end :: printJavaScriptHandler
	
	
		  //*****************************//
		 //********** TESTERS **********//
		//*****************************//
	
	/**
	 * Tests if object is handling a object method
	 * 
	 * @access public
	 * @since 0.1 - 01/07/2005
	 * @param	void	void
	 * @return	bool	I'm handling a method
	 */
	function handlingMethod() {
		return is_array($this->serverSideFunction);
	} // end :: handlingMethod
	
	
	/**
	 * Return true if the object already printed his JavaScript. False otherwise.
	 * 
	 * @access public
	 * @since 0.1 - 01/07/2005
	 * @param	void	void
	 * @return	bool	Already printed 
	 */
	function hasPrintedJavaScriptHandler() {
		return (bool) $this->javaScriptHandlerPrinted;
	} // end :: hasPrintedJavaScriptHandler
	

	
		  //*****************************//
		 //********** GETTERS **********//
		//*****************************//
	
	/**
	 * Getter for this object attributes
	 * 
	 * @access public
	 * @since 0.1 - 01/07/2005
	 * @param	string	$attribute	Attribute name
	 * @return	mixed	The $attribute value
	 */
	function get($attribute) {
		
		// Attributes that you can get from outside the class
		$validAttributes = array('onEvent', 'clientSideObjectName', 'serverSideFunction', 'serverSideParameters', 'jsFirerFunctionName', 'jsReturnFunctionName');
		
		if ( !in_array($attribute, $validAttributes) ) {
			$this->triggerError("$attribute is not accessible outside class or is not a valid attribute", E_USER_ERROR);
			return;
		}
		
		return $this->$attribute;
		
	} // end :: get
	
	
	/**
	 * Get the function name that need to be used on client side call
	 * 
	 * @access public
	 * @since 0.1 - 01/07/2005
	 * @param	void	void
	 * @return	string	Function name
	 */
	function getClientSideFunctionName() {
		
		return CajaxEventHandler::callbackInfoToString( $this->serverSideFunction );
			
	} // end :: getClientSideFunctionName
	

	/**
	 * Returns javascript filenames to be loaded to CajaxInterface
	 * 
	 * @access public
	 * @since 0.1.2 - 12/08/2005
	 * @param	void	void
	 * @return	array	Javascript files
	 */
	function getIncludedJSFiles() {
		return $this->includedJSFiles;
	} // end :: getIncludedJSFiles

	
	
		  //*****************************//
		 //********** SETTERS **********//
		//*****************************//
	
	/**
	 * Set a value for object attribute
	 * 
	 * @access public
	 * @since 0.1 - 01/07/2005
	 * @param	string	$property	Attribute name
	 * @param	mixed	$value		The Attribute value
	 * @return	void
	 */
	function set($attribute, $value) {
		
		// Attributes that you can set from outside the class
		$validAttributes = array('onEvent', 'clientSideObjectName', 'serverSideFunction', 'serverSideParameters', 'jsFirerFunctionName', 'jsReturnFunctionName');
		
		if ( !in_array($attribute, $validAttributes) ) {
			$this->triggerError("$attribute is not accessible outside class or is not a valid attribute", E_USER_ERROR);
			return;
		}
		
		$this->$attribute = $value;
		
	} // end :: set
	
	
} // end :: class

?>