<?php
	// *** HERE, YOUR PHP SCRIPT *** //

//////////////////////////////////////////	
//	+-------------------------------+	//
//	|								|	//
//	| 		A CLASS DEFINITION		|	//
//	|								|	//
//	+-------------------------------+	//
//////////////////////////////////////////

// This might be in a include file...
class localizations {
	
	function processNothing() {		// Sleep for something between 0 and 2 seconds.	
		sleep( rand(0, 200)/100 );	// Just to simulate some processing (like database query) and see "Loading..." message... :)
	}

	function getStates($idCountry) {
		
		localizations::processNothing();

		switch($idCountry) {		// Would be cool getting data from database... :P
			case 55:
				return array(''=>'', 'Rio de Janeiro', 'S�o Paulo', 'Minas Gerais', 'Bahia', 'Amazonas');
			case 66:
				return array(''=>'', 6=>'Buenos Aires');
			case 2:
				return array(''=>'', 7=>'Paris', 'Lyon', 'Marceille');
			case 3:
				return array(''=>'', 10=>'Roma', 'Milan', 'Veneza');
			case 4:
				return array(''=>'', 13=>'-');
			default:
				return array();
		
		}
		
	}
	
	function getCountries($continent) {		// For countries, now...
		
		localizations::processNothing();
		
		switch($continent) {
			case 1:
				return array(''=>'', 55=>'Brasil', 66=>'Argentina');
			case 2:
				return array(''=>'', 2=>'France', 3=>'Italy');
			default:
				return array(''=>'', ''=>'Other');
		}
		
	}
	
}

//////////////////////////////////
//	+-----------------------+	//
//	|						|	//
//	| 		CAJAX PART		|	//
//	|						|	//
//	+-----------------------+	//
//////////////////////////////////
	
	

	// Begin the Cajax definitions
require("../../../../../CajaxInterface.php");	// Require CajaxInterface

$Cajax = new CajaxInterface();	// Creates CajaxInterface

// Creates two Cajax SelectIntegration Handlers (for dealing with the two select changes event: one for continent change, other for country change)
														/* Source Object ID | Target Object ID | Function or method to call | Server side parameters (empty array for none) | "Wait" message */
$SelectChangeContinent = new CajaxSelectIntegrationHandler('continent', 'country', 'localizations::getCountries', array(), 'Loading countries...');
$SelectChangeCountry = new CajaxSelectIntegrationHandler('country', 'state', 'localizations::getStates', array(), 'Loading states...');

// Add the two handlers to interface
$Cajax->addHandler( $SelectChangeContinent );
$Cajax->addHandler( $SelectChangeCountry );


$Cajax->handleAll();

// It's just to see the submited form...
if(isset($_POST) && count($_POST)) {
	echo "<pre>";
	print_r($_POST);
	echo "</pre>";
}
?>

<html>
<head>

	<title> Cajax SelectIntegration test </title>
	
	<? $Cajax->displayJSInterface(); // Display javascript code ?>
</head>

<body>

<form method="POST">

<!-- With an "onload" event to clear state selection box. No conflicts with Cajax Handler... :) -->
<!-- Ah! clear() method is not javascript built in. It's defined by the handler -->
<select name="continent" id="continent" onchange="document.getElementById('state').clear();">
	<option value=""></option>
	<option value="1">America</option>
	<option value="2">Europe</option>
</select>

<select name="country" id="country">
	<option value="">Choose a continent</option>
</select>

<select name="state" id="state">
	<option value="">Choose a country</option>
</select>

<input type="submit" value="Submit">

</form>

</body>
</html>