<?php
/**
 * Cajax Select Integration Handler
 * 
 * Uses Cajax interface for filling one select based on a selected value of another select box.
 * 
 * ******************* LICENCE *******************
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Lesser General Public License along 
 * with this library; if not, write to the Free Software Foundation, Inc., 59 
 * Temple Place, Suite 330, Boston, MA 02111-1307 USA 
 * ***********************************************
 * 
 * This class help programmer to do select integrations, using XMLHttpRequest to fill a select based on
 * the value of the selected index from another select. Pretty usefull for doing Country/State/City(/quarter?)
 * multiple selects: you can fill State select thought a server-side requisition after user has selected his country.
 * The same for the city, after selecting state. Everything without page refresh. :)
 * 
 * When you change the box selection, Cajax will call you $serverSideFunction (that can be a function or a method -static or not) 
 * passing as first parameter the value selected. Your server side function need to return an array with key=>value pars.
 * This values will be used as value and text for the options that will fill the target select.
 * 
 * Your $serverSideFunction return needs to look like this:
 * 	return array (
 * 				1 => 'First item selected',
 * 				2 => 'Second item selected',
 * 				'-' => 'Don't wanna select nothing
 * 			);
 * 
 * Than, after executing it, the handler will generate something like this between your <select> and </select>:
 * 		<option value="1">First item selected</option>
 * 		<option value="2">Second item selected</option>
 * 		<option value="-">Don't wanna select nothing</option>
 * 
 * It's easy! Take a look at Examples folder!
 * 
 * @author Thiago F. Pappacena
 * @license http://www.opensource.org/licenses/lgpl-license.php LGPL
 * @example Examples/test1.example.php	A cool way of using SelectIntegration handler
 * @see	CajaxEventHandler
 * @see CajaxInterface
 * @version 0.1
 */
class CajaxSelectIntegrationHandler extends CajaxEventHandler {
	
	/**
	 * @access protected
	 * @since 0.1 - 31/08/2005
	 * @var string The select ID where values will be populated
	 */
	var $target;
	
	/**
	 * @access protected
	 * @since 0.1 - 31/08/2005
	 * @var string The select source (Reference for superclasse's clientSideObjectName)
	 */
	var $source;
	
	/**
	 * @access protected
	 * @since 0.1 - 31/08/2005
	 * @var string Message to be displayed in target select while retrieving data from server side
	 */
	var $waitMessage;
	
	
	/**
	 * Constructor
	 * 
	 * @access public
	 * @since 0.1 - 31/08/2005
	 * @param	string	$sourceElement			The element that will call server side and fill another select
	 * @param	string	$targetElement		The element to fill after server side call
	 * @param	string	$serverSideFunction		Server side function name that will be called on $sourceElement select change
	 * @param	array	$serverSideParameters	Server side parameters to be passed to server side function [optional]
	 * @param	string	$waitMessage			Message to be displayed at target select while retrieving information from server
	 */
	function CajaxSelectIntegrationHandler(
								$sourceElement, 
								$targetElement, 
								$serverSideFunction, 
								$serverSideParameters = array(),
								$waitMessage = "Loading...")
	{

		parent::CajaxEventHandler($sourceElement, 'onchange', $serverSideFunction, "function (array) { cjxElem('{$targetElement}').fill(array); }", "function () { cjxElem('{$targetElement}').setWaitMode('{$waitMessage}'); cjxElem('{$sourceElement}').requestFill(); }", $serverSideParameters);
		
		$this->target = $targetElement;
		$this->source = &$this->clientSideObjectName;
		$this->waitMessage = $waitMessage;
		
		$this->includedJSFiles[] = dirname(__FILE__).'/JS/selectintegrationBase.js';

	} // end :: CajaxSelectIntegrationHandler [constructor]
	
	
	
	/**
	 * Prepare client side JavaScript 
	 * 
	 * @access protected
	 * @since 0.1 - 31/08/2005
	 * @param	void	void
	 * @return	void
	 */
	function prepareClientSide() {
		
		parent::prepareClientSide();
		
		// here, the div is constructed and atributes and methods given to the input element...
		$this->javaScriptHandler .= 
			"	if ( (inp = cjxElem('{$this->clientSideObjectName}')) == null) throw new RefEvExcp();

				d = cjxElem('{$this->target}');
				d.fill = fillSelect;
				d.clear = clear;
				d.addSingleOption = addSingleOption;
				d.setWaitMode = setWaitMode;

				cjxElem('{$this->source}').requestFill = requestFill;";				
		
	} // end :: prepareClientSide
	
	
	
	/**
	 * Execute server-side function and returns to Cajax call a JavaScript array with
	 * arrys of text/value pairs to fill target selects
	 * 
	 * @access protected
	 * @since 0.1 - 31/08/2005
	 * @param	array	$parameters Array of parameters to pass do handled function
	 * @return	void	void
	 */
	function executeServerSideFunction($parameters) {

		if ( $this->handlingMethod() )	// Handling a method
			$callback = array ( $this->serverSideFunction['object'], $this->serverSideFunction['method'] );
		else
			$callback = $this->serverSideFunction;

		$parameters = array_merge($this->serverSideParameters, $parameters);
		$itens = call_user_func_array($callback, $parameters);

		$jsItens = array();
		foreach($itens as $value=>$text)
			$jsItens[] = "new Array('". addslashes($value) ."', '". addslashes($text) ."')";

		print "new Array (". implode(',', $jsItens) .");";
		exit;
		
	} // end :: executeServerSideFunction
	
	
} // end :: class
?>