// Receiver an array like the above and fill the select
// Array example:
// new Array (
//		new Array("value", "text"),
//		new Array("55", "Brasil")
// );
// (To associate with destination select input)
function fillSelect(array) {

	if (typeof array == 'string')
		eval("array = "+ array);

	this.clear();
		
	end = array.length;
	for(i=0 ; i<end ;i++)
		this.addSingleOption(array[i]);
	this.disabled = false;
	
}


// Remove all options from the select
function clear() {
	end = this.length-1;
	for(i=end ; i>=0 ; i--)
		this[i] = null;
}


// Add an option to the select
function addSingleOption(optionArray) {

	Op = new Option();
	Op.value = optionArray[0];
	Op.text = optionArray[1];
	
	this[ this.length ] = Op;

}


// set wait mode to select, removing all it's options and disableing him
function setWaitMode(loadingMessage) {
	this.clear();
	this.addSingleOption( new Array('', loadingMessage) );
	this.disabled = true;
}


// Request data to destination select to server-side
// (To associate with source select input)
function requestFill() {
	this.Cajax.onchange( this[ this.selectedIndex ].value );
}