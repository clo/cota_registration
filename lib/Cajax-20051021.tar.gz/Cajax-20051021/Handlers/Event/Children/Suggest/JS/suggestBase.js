// Find the X position of the object O
function posX(O) {
	if (O.x) return O.x;
	if (O.offsetParent) return O.offsetLeft + posX(O.offsetParent);
	return O.offsetLeft;
}

// Find the Y position of the object O
function posY(O) {
	if (O.y) return O.y;
	if (O.offsetParent) return O.offsetTop + posY(O.offsetParent);
	return O.offsetTop;
}

// Creates a new suggest DIV with id = name for the inp 
function createSuggestDiv(name, inp) {
	d = document.createElement('DIV');
	d.id = name;
	s = d.style;
	s.position = 'absolute';
	s.left = posX(inp) +"px";
	s.top = ( posY(inp)+inp.offsetHeight )+"px";
	s.width = inp.offsetWidth+ "px";
	document.getElementsByTagName('body')[0].appendChild(d);
	return d;
}

// Remove rows from table
function removeRows(tbl) {

	if (!tbl) return;

	if (tbl.nodeName == 'TBODY')
		tbl = tbl.parentNode;
		
	if ( (rows = getRows(tbl)) && rows.length )
		for(i=rows.length - 1 ; i>=0 ; i--)
			tbl.deleteRow(i);
	
}

// Returns the rows from a table
function getRows(tbl) {
	if (!tbl) return;

	if (tbl.nodeName == 'TBODY')
		tbl = tbl.parentNode;
	return tbl.getElementsByTagName('TR');
}

// Move the selection focus through list of suggestions (receives an event object)
function moveSelection(ev) {
	e = ev? ev : event;
	kc = e.keyCode? e.keyCode : e.which;

	inp = e.srcElement? e.srcElement : e.target;
	t = inp.getTable(true);
	r = getRows(t);

	switch (kc) {
		case 38:	// up arrow
		case 40:	// down arrow
			if (!t) return;

			if (inp.selectedIndex == -1)
				i = (kc == 40)? 0 : r.length - 1;
			else if (kc == 40)
				i = (inp.selectedIndex + 1) % r.length;
			else 
				i = inp.selectedIndex == 0? r.length -1 : inp.selectedIndex - 1;

			inp.selectSuggestion(i);
			preventDefault(e);
			break;

		case 8:		// backspace
		case 46:	// delete
			inp.unselectSuggestions();
			break;
			
		case 9:		// tab
			if (inp.selectedIndex == -1)
				inp.selectSuggestion(0);
			else {
				inp.setSelection((x = inp.value.length), x);
				removeRows(t);
			}
			preventDefault(e);
			break;

		case 13:	// enter
			if (getRows(t).length > 0) {
				removeRows(t);
				inp.setSelection((x = inp.value.length), x);
				preventDefault(e);
			}
			break;
		default:
			break;
	}

}

/////////////////////////////////////////////////////////////////////

//	'REFERENCING' FUNCTIONS

//	This functions are object methods. They appear here for reducing the number of 
//	output to be created and sent to client.

//	WAY OF USING:
//		Example:
//			getDiv function need to be associated to a input being handled by a SuggestionHandler
//			In javascript code, something like this will be done:
//				input = cjxElem('input_id');
//				inpup.getDiv = getDiv;
//			Just it... :P
/////////////////////////////////////////////////////////////////////

// Returns the table associated with object
function getTable(tbody) { 
	if (tbody && this.table.childNodes[0])
		return this.table.childNodes[0];
	else
		return this.table;
}

// Returns the div associated with object 
function getDiv() { 
	return this.div;
}

// Replace the selected text inside inpup by repl
function replaceSelection(repl) {
	var len = repl.length;
    if (this.setSelectionRange) {
        ini = this.selectionStart;
        end = this.selectionEnd;

        this.value = this.value.substring(0, ini) + repl + this.value.substring(end);
		this.selectionStart  = ini + len;
		this.selectionEnd  = ini + len;
    }
    else if (document.selection) {
        r = document.selection.createRange();
        ini = r.selectionStart;

        if (r.parentElement() == this) {
			r.text = repl;
			r.moveStart("character", ini + len);
			r.moveEnd("character", ini + len);
			r.select();
        }
    }
    this.focus();
}

// Gets the selected text inside the textbox
function getSelection() {
	if (this.setSelectionRange)
		return this.value.substring(this.selectionStart, this.selectionEnd);
	else if (document.selection) {
		r = document.selection.createRange();
		return r.text;
	}
	return "";
}

// Set a selection inside a input
function setSelection(ini, end) {
    if (this.setSelectionRange) {
        this.setSelectionRange(ini, end);
    }
    else if (this.createTextRange) {
        r = this.createTextRange();
        r.collapse(true);
        r.moveEnd("character", end);
        r.moveStart("character", ini);
        r.select();
    }
    this.focus();
}

// Unselect all suggestions of the object
function unselectSuggestions() {
	c = this.getTable(true).childNodes;
	for(i=0 ; i<c.length ; i++) {
		c[i].childNodes[0].className = this.suggestionClassName;
	}
	this.selectedIndex = -1;
}

// Selects the suggestion number i of the inp
function selectSuggestion(i) {
		
	tbl = this.getTable(true);

	if ( !(td  = tbl.childNodes[i]) || !(td = td.childNodes[0]) )
		return;

	if (!td.innerHTML || !td.innerHTML.length)
		return;
	this.unselectSuggestions();
	this.selectedIndex = i;

	td.className = this.selectedSuggestionClassName;

	inp.replaceSelection('');
	ini = this.value.length;
	this.value = td.innerHTML;
	this.setSelection(ini, this.value.length);
}

// Display the array of suggestions (sug) to input
function suggest(sug) {

	if (typeof sug == 'string')	// If it's a string, evaluates to array...
		eval('sug = '+sug);

	d = this.getDiv();
	t = this.getTable(false);
	t.width = '100%';
	selI = this.selectedIndex;

	removeRows(t);

	this.unselectSuggestions();
	if (sug.length == 0) {
		this.unselectSuggestions();
		return;
	}

	// Creates table rows
	for (i=0 ; i<sug.length ; i++) {
		tr = t.insertRow(-1);
	
		td = tr.insertCell(-1);
		td.numPosition = i;
		td.appendChild( document.createTextNode(sug[i]) );	// Puts the suggested text inside TD
		td.className = this.suggestionClassName;
		eval("td.onmouseover = function() {cjxElem('"+ this.id +"').selectSuggestion(this.numPosition)};");
		eval("td.onclick = function () { inp = cjxElem('"+ this.id +"'); removeRows(inp.getTable(true)); inp.setSelection((x = inp.value.length), x); }; inp.focus();");
	}
	d.style.height = t.offsetHeight;

}

// Request a suggestion to server
function requestSuggestions(ev) {
	e = ev? ev : event;
	kc = e.keyCode? e.keyCode : e.which;
	
	switch (kc) {
		case 38:	// up arrow
		case 40:	// down arrow
		//case 8:		// backspace
		case 46:	// delete
		case 13:	// enter
		case 9:		// tab
		case 37:	// left arrow
		case 39:	// right arrow
		case 33:	// page up
		case 34:	// page down
		case 36:	// home
		case 35:	// end
		case 27:	// esc
		case 16:	// shift
		case 17:	// ctrl
		case 18:	// alt
		case 20:	// caps lock
		    return true;
		default:
			inp = this;
			
			c = String.fromCharCode(kc);
			if (!e.shiftKey)
				c = c.toLowerCase();
			// Call server side passing the input value + the key pressed
			inp.Cajax.onkeypress(inp.value + c);

	}
}