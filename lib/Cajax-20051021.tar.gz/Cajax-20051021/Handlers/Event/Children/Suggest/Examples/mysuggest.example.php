<?php
/*
 * A directory autocomplete :)
 */

// A test class...
class MyComputer {
	
	// Read all directories from server witch names begin with the parameter
	function getDirectories($beginingWith = "") {
		
		return glob("{$beginingWith}*", GLOB_ONLYDIR);
		
	}
	
}

require("../../../../../CajaxInterface.php");	// Require CajaxInterface

$Cajax = new CajaxInterface();

$SuggestDir = new CajaxSuggestHandler("dir", 'MyComputer::getDirectories', 'suggestStyle', 'selectedSuggestion');

$Cajax->addHandler( $SuggestDir );

$Cajax->handleAll();
?>

<html>
<head>
	<meta http-equiv="Content-Language" content="en" />
	<meta name="GENERATOR" content="PHPEclipse 1.0" />
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	
	<title>Suggestion handler example</title>
	
	<? $Cajax->displayJSInterface(); ?>
	
	<style>
		.normal {
			font-face: arial;
			font-size: 11px;
			color: #3F3F3F;
		}
		
		.bold {
			font-face: arial;
			font-size: 11px;
			color: #3F3F3F;
			font-weight: bold;
		}
		
		.suggestStyle {
			padding: 0px;
			spacing: 0px;
			/* border: 1px solid black; */
			font-size: 11px;
			color: #0F0FB3;
			font-face: arial;
			background-color: #FAFAFA;
		}
		
		.selectedSuggestion {
			padding: 0px;
			spacing: 0px;
			font-size: 11px;
			color: #0F0BF3;
			font-face: arial;
			background-color: #FBF0F0;		
		}

	</style>

</head>
<body bgcolor="#FFFFFF" text="#000000" link="#FF9966" vlink="#FF9966" alink="#FFCC99">


<div class="bold"> Select the server dir: <input type="text" name="dir" value="" id="dir" class="bold" size="40"></div>


</body>
</html>
  