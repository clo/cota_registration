<?php
/**
 * Cajax Suggest Handler
 * 
 * Uses CajaxEventHandler to creates a autocomplete using server-side calls
 * This classes needs to be used with CajaxInterface AND CajaxEventHandler, which are included in another files.
 * 
 * For bug reports (or donation :P), please contact pappacena@gmail.com
 * 
 * 
 * ******************* LICENCE *******************
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Lesser General Public License along 
 * with this library; if not, write to the Free Software Foundation, Inc., 59 
 * Temple Place, Suite 330, Boston, MA 02111-1307 USA 
 * ***********************************************
 * 
 * 
 * 
 * This class abstracts a cool use of CajaxEventHandler: a autocomplete based on server-side
 * informations. Listening keypress on an input, this class will call server side, fetch informations,
 * create a DIV element on browser and show informations fetched from server there. Then user
 * can use arrow keys to navigate and select results. :)
 * 
 * NOTE:
 * 		$serverSideFunction is the functions that will be called to fetch informations that will
 * 		show autocomplete box. This will receive as first parameter what user have writed in textbox
 * 		until the Cajax call. Inside the function, you may use database query or regex to find informations
 * 		about what user is writing, and you may decide to not show anything until user write a certain number
 * 		of caracters.
 * 		This $serverSideFunction needs to return an array of informations that will be sent to client
 * 		as the autocomplete box. Example:
 * 			function autocomplete($txt) {
 * 				if ( strlen($txt < 5) )	// Less than 5 caracters?
 * 					return array();		// No query and no autocomplete
 * 				return $db->getRow("SELECT name FROM users WHERE name like '{$txt}%'");
 * 			}
 * 
 * 		$serverSideFunction may be a (static or not) method from a class (or object). To use it, see
 * 		CajaxEventHandler comments about OOP handling
 * 
 * 
 * @author Thiago F. Pappacena
 * @license http://www.opensource.org/licenses/lgpl-license.php LGPL
 * @example Examples/mysuggest.example.php	How to use suggestHandler to autocomplete input with server's directories names
 * @see	CajaxEventHandler
 * @see CajaxInterface
 * @version 0.2
 */
class CajaxSuggestHandler extends CajaxEventHandler {

	/**
	 * @access protected
	 * @since 0.1 - 22/07/2005
	 * @var	string	CSS class name for autocomplete box
	 */
	var $boxClass;
	
	/**
	 * @access protected
	 * @since 0.1 - 22/07/2005
	 * @var	string	CSS class name for selected line in autocomplete box
	 */
	var $selectedBoxClass;

	
	
	/**
	 * Constructor
	 * 
	 * @access public
	 * @since 0.1 - 05/08/2005
	 * @param	string	$clientSideObjectName Client-side textbox ID
	 * @param	string	$serverSideFunction Server-side function to be called on keypress
	 * @param	string	$boxClass CSS class for autocomplete box (like border, cellpadding, etc)
	 * @param	string	$selectedBoxClass The same as the above, but for selected itens
	 * @param	array	$serverSideParameters Array of parameters to be passed to server-side function [optional]
	 * @see CajaxEventHandler::CajaxEventHandler
	 */
	function CajaxSuggestHandler($clientSideObjectName, $serverSideFunction, $boxClass = "", $selectedBoxClass = "" , $serverSideParameters = array()) {
		
		parent::CajaxEventHandler($clientSideObjectName, 'onkeypress', $serverSideFunction, "function (array) { cjxElem('{$clientSideObjectName}').suggest(array); }", "function (ev) { e = ev? ev : event; cjxElem('{$clientSideObjectName}').requestSuggestions(e); }", $serverSideParameters);
		$this->includedJSFiles[] = dirname(__FILE__).'/JS/suggestBase.js';
		$this->boxClass = $boxClass;
		$this->selectedBoxClass = (strlen($selectedBoxClass))? $selectedBoxClass : $boxClass;
		
	} // end :: CajaxSuggestHandler [constructor]
	
	
	
	/**
	 * Prepare client side JavaScript 
	 * 
	 * @access protected
	 * @since 0.1 - 05/08/2005
	 * @param	void	void
	 * @return	void
	 */
	function prepareClientSide() {
		
		parent::prepareClientSide();

		// *** CREATES DIV TO INPUT *** //
		//$table = "<table ". addslashes(addslashes($this->boxAtributes)). "></table>";	// Table HTML
		
		// here, the div is constructed and atributes and methods given to the input element...
		$this->javaScriptHandler .= 
			"	if ( (inp = cjxElem('{$this->clientSideObjectName}')) == null) throw new RefEvExcp();

				d = createSuggestDiv('sgst_{$this->clientSideObjectName}', inp);

				t = document.createElement('TABLE');
				//t.className = '{$this->boxClass}'; 
				t.id = 'tbl_{$this->clientSideObjectName}';
				t.cellPadding = 0;
				t.cellSpacing = 0;

				d.appendChild(t);

				// Atributes
				inp.setAttribute('autocomplete', 'off');
				inp.div = d;
				inp.table = inp.div.childNodes[0];
				inp.selectedIndex = -1;
				inp.selectedSuggestionClassName = '{$this->selectedBoxClass}';
				inp.suggestionClassName = '{$this->boxClass}';

				// Methods
				inp.getDiv = getDiv;
				inp.getTable = getTable;
				inp.unselectSuggestions = unselectSuggestions;
				inp.selectSuggestion = selectSuggestion;
				inp.getSelection = getSelection;
				inp.setSelection = setSelection;
				inp.requestSuggestions = requestSuggestions;
				inp.suggest = suggest;
				inp.replaceSelection = replaceSelection;

				// Events
				addEvent(inp, 'blur', function() { removeRows(this.table); this.selectedIndex = -1; });

				// IE-like browsers can preventDefault from enter on keydown. Mozilla family can't. So, a little bit of 'bambiarra' ;)
				onEvent = document.all? 'keydown' : 'keypress';
				addEvent(inp, onEvent, moveSelection);";				
		
	} // end :: prepareClientSide
	
	
	
	/**
	 * Execute server-side function and returns to Cajax call a JavaScript array with
	 * texts to be inserted in autocomplete box
	 * 
	 * @access protected
	 * @since 0.1 - 05/08/2005
	 * @param	array	$parameters Array of parameters to pass do handled function
	 * @return	void	void
	 */
	function executeServerSideFunction($parameters) {

		if ( $this->handlingMethod() )	// Handling a method
			$callback = array ( $this->serverSideFunction['object'], $this->serverSideFunction['method'] );
		else
			$callback = $this->serverSideFunction;

		$parameters = array_merge($this->serverSideParameters, $parameters);
		$suggestions = call_user_func_array($callback, $parameters);

		print "[\"". implode('", "', $suggestions). "\"]";
		exit;
		
	} // end :: executeServerSideFunction
	
} // end :: class
?>