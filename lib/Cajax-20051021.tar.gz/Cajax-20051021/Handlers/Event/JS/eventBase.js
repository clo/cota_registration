// Event handler exception object
function RefEvExcp(){
	msg = 'document.getElementById ReferenceError on event handler';
	this.message=msg; this.name=msg;
}

function callServerSide(functionName, args){
	uri = document.location.toString().replace('#', '');	// Remove anchor from document.location
	
	// What to pass to server-side?
	dataToPost = 'CajaxEventHandler_function=' + escape(functionName);
	for (i=0 ; i<args.length-1 ; i++)
		dataToPost += '&CajaxEventHandler_parameters[]=' + escape(args[i]);

	Cajax.doRequest(uri, dataToPost, 'POST', args[args.length-1]);
}