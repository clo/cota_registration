<?php
	// *** HERE, YOUR PHP SCRIPT *** //
function printHello() {
	print "Hello, world!\nRoot at ". $_SERVER['DOCUMENT_ROOT'];
}	
	

	// Begin the Cajax definitions
require("../../../CajaxInterface.php");	// Require CajaxInterface

$Cajax = new CajaxInterface();	// Creates CajaxInterface

// Creates a new event handler														/* Source Object ID | Target Object ID | Function or method to call | Server side parameters (empty array for none) | "Wait" message */
$EventHandler = new CajaxEventHandler('testButton', 'onmouseover', 'printHello');

// Add the two handlers to interface
$Cajax->addHandler( $EventHandler );


$Cajax->handleAll();

?>

<html>
<head>

	<title> Cajax SelectIntegration test </title>
	
	<? $Cajax->displayJSInterface(); // Display javascript code ?>
</head>

<body>

<input type="button" id="testButton" value="Do a mouseover here">

</body>
</html>