<?php

/*
 * An EventHandler example using object and not default behavior (not alerting, but writing server call to a div),
 * and passing client-side values as parameter to server-side method.
 * 
 * For more examples, take a look at Childs folder, where are the Handlers that extends EventHandler functionality 
 */

	// *** HERE, YOUR PHP SCRIPT *** //
class Dummy {
	
	var $name;
	
	function setName($name) {
		$this->name = $name;
	}
	
	function getName() {
		return $this->name;
	}
	
	// Return some dummy string concatenated with $test parameter
	function getAnything($test) {
		return "Hum? Are you talking to me? {$test}";
	}
	
}
	
	
$DummyTest = new Dummy();
$DummyTest->setName('Thiago F Pappacena');


	// Begin the Cajax definitions
require("../../../CajaxInterface.php");	// Require CajaxInterface

$Cajax = new CajaxInterface();	// Creates CajaxInterface

// Creates a new event handler
$EventHandler = new CajaxEventHandler('testButton', 'onblur', 'DummyTest->getAnything', 'writeResponse', 'function () { btn = document.getElementById("testButton"); btn.Cajax.onblur( btn.value ); }');
// Trigger and return function can be just the javascript function name or the function definition...



$Cajax->addHandler( $EventHandler );

$Cajax->handleAll();

?>

<html>
<head>

	<title> Cajax SelectIntegration test </title>
	
	<? $Cajax->displayJSInterface(); // Display javascript code ?>
	<script>
		function writeResponse(resp) {
			document.getElementById('response').innerHTML = resp;
		}
	</script>
</head>

<body onload="document.getElementById('testButton').focus();">

<div id="response"></div>

<input type="text" id="testButton" value="Remove my focus to do server call" size="35">


</body>
</html>