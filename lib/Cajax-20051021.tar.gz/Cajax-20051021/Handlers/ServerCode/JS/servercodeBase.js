// Make a syncronous call for server side, returning an array, where
// return[0] = server function's return
// return[1] = server function's output
function executeServerCode(functionName, args) {
	uri = document.location.toString().replace('#', '');	// Remove anchor from document.location

	// What to pass to server-side?
	dataToPost = 'CajaxServerCodeHandler_function=' + escape(functionName);
	for (i=0 ; i<args.length ; i++)
		dataToPost += '&CajaxServerCodeHandler_parameters[]=' + escape(args[i]);
		
	ret = Cajax.doRequest(uri, dataToPost, 'POST');
	return splitServerResponse(ret);

}

function splitServerResponse(resp) {
	ret = new Array(2);
	ret[0] = "";		// Return
	ret[1] = "";		// Output
	
	index = 0;	// Index being filled with the return.
		// 0 -> Return index
		// 1 -> Output index

	len = resp.length;
	for(i=0 ; i<len ; i++) {		// foreach caracter in response
		c = resp.charAt(i);
		
		if ( c == '|' ) {				// If it's pipe,
			if ( resp.charAt(i+1) == '|' ) {	// If it's escaped pipe, thet's not the end of return from server-side function
				i++;					// Just increment (to copy only one pipe)
			}
			else {						// If it's not escaped,
				index = 1;				// Time to copy to output index
				continue;				// Continue (and don't copy the pipe)
			}
		}
		
		ret[index] += c;			// Put the caracter in "return"
	}

	return ret;
	
}