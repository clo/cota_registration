<?php
/**
 * Cajax Server Code Handler
 * 
 * Defines in Javascript the function or method defined in PHP
 * 
 * A handled method will be avaliable at javascript:Cajax.server.object.method()
 * A handled function will be avaliable at javascript:Cajax.server.function()
 * 
 * For bug reports (or donation :P), please contact pappacena@gmail.com
 * 
 * 
 * ******************* LICENCE *******************
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Lesser General Public License along 
 * with this library; if not, write to the Free Software Foundation, Inc., 59 
 * Temple Place, Suite 330, Boston, MA 02111-1307 USA 
 * ***********************************************
 *  
 * @author Thiago F. Pappacena
 * @license http://www.opensource.org/licenses/lgpl-license.php LGPL
 * @example	Examples/codehandler.example.php	An simple example of how to use ServerCodeHandler
 * @see	CajaxInterface
 * @version 0.1
 */
class CajaxServerCodeHandler extends CajaxHandler {
	
	/**
	 * @access protected
	 * @since 0.1 - 30/09/2005
	 * @var array Info array for callback function handled by CajaxServerCodeHandler
	 */
	var $functionInfo;
	
	/**
	 * @access protected
	 * @since 0.1 - 30/09/2005
	 * @var array ID of the page element where to insert default function/method output
	 */
	var $defaultOutputDIV;
	
	/**
	 * @access protected
	 * @since 0.1 - 30/09/2005
	 * @var	array	Array of parameters to be used on server side call. This array will be passed BEFORE the client side parameters
	 */
	var $serverSideParameters;
	
	
	/**
	 * Constructor
	 * 
	 * @access public
	 * @since 0.1 - 30/09/2005
	 * @param	string	$function			Function or method to be handled
	 * @param	string	$defaultOutputDIV	DIV ID where to put default server-side function's output
	 */
	function CajaxServerCodeHandler($function, $defaultOutputDIV = "", $serverSideParameters = array()) {
		parent::CajaxHandler();
		
		$this->includedJSFiles[] = dirname(__FILE__).'/JS/servercodeBase.js';
		
		$this->functionInfo = CajaxServerCodeHandler::convertToCallbackInfo( $function );
		$this->defaultOutputDIV = $defaultOutputDIV;
		$this->serverSideFunction = $serverSideParameters;
		$this->serverSideParameters = $serverSideParameters;
		
	} // end :: CajaxServerCodeHandler [constructor]
	
	
	
	/**
	 * Prepare client side script
	 * 
	 * @access public
	 * @since 0.1 - 30/09/2005
	 * @param	void	void
	 * @return	void
	 */
	function prepareClientSide() {
		
		$functionString = CajaxServerCodeHandler::callbackInfoToString( $this->functionInfo  );
		
		$jsFunctionString = str_replace('->', '.', $functionString);
		$jsFunctionString = str_replace('::', '.', $jsFunctionString);
		
		// If it's a class/object method, it need to be defined in javascript
		if ( is_array($this->functionInfo) ) {
			
			$objectName = ( isset($this->functionInfo['objectName']) )?
							 $this->functionInfo['objectName'] :
							 $this->functionInfo['object'];
			
			$this->javaScriptHandler .=
			"	if ( Cajax.server.{$objectName} == undefined )
					Cajax.server.{$objectName} = new Object;
			";
			
		}
		
		// Where to put the output from server call
		if ( $this->defaultOutputDIV )	// If there's a default output DIV, that's where output have to be inserted
			$output = "if (element = cjxElem('$this->defaultOutputDIV') ) element.innerHTML = ret[1];";
		else						// Otherwise, alert it
			$output = "if(ret[1].length) alert(ret[1]);";
		
		$this->javaScriptHandler .=
		"	Cajax.server.$jsFunctionString = function () {
							ret = executeServerCode( '{$functionString}', Cajax.server.$jsFunctionString.arguments );
							$output
							return ret[0];
						};
		";
		
	} // end :: prepareClientSide
	
	/*
	 * Why are you trying to make fun of me?
	 * You think it's funny what the fuck you think is doing to me?
	 * You take your turn lashing out of me!
	 * I want you crying with your dirty ass in front of me!
	 * 
	 * All my hate cannot be found
	 * I will not be drowned by your thoughtless scheming
	 * You can try to tear me down,
	 * Beat me to the ground
	 * I'll see you screaming
	 */
	
	
	/**
	 * Execute the handled server side function passing $parameters
	 * 
	 * @access protected
	 * @since 0.1 - 01/07/2005
	 * @param	array	$parameters	Array of parameters to pass do handled function
	 * @return	void
	 */
	function executeServerSideFunction($parameters) {
		ob_start();				
		$callback = &CajaxEventHandler::callbackInfoToCallback( $this->functionInfo );

		if ( is_array($parameters) )
			$parameters = array_merge($this->serverSideParameters, $parameters);
		else
			$parameters = $this->serverSideParameters;
			
		// Since the caracter "|" is used to separate return from output data, all "|" is escaped by
		// another "|" before it, as is done with backslashes in addslash() function
		// In client-side, whe need to manipulate this...

			$return = str_replace("|", "||", call_user_func_array($callback, $parameters) );
			$output = str_replace("|", "||", ob_get_clean() );
		ob_end_clean();
		
		print "{$return}|{$output}";		
		exit;
		
	} // end :: executeServerSideFunction
	
	
	
	/**
	 * Executes the function if it's a Cajax call for this
	 * 
	 * @access public
	 * @since 0.1 - 30/09/2005
	 * @param	void	void
	 * @return	void
	 */
	function handle() {
		
		parent::handle();
		
		if (headers_sent())		// Data already sent? It may not be what we want!
			$this->triggerError("Output data already sent to client. The Server Code Handler may not work as desired.<br/>To avoid it, use handle() method before sending output to client machine<br/>" , E_USER_WARNING);
		
		// If it's a Cajax Server Code call
		if ( isset($_POST) && isset($_POST['CajaxServerCodeHandler_function']) && trim($_POST['CajaxServerCodeHandler_function']) ) {
			
			$callingInfo = &CajaxServerCodeHandler::convertToCallbackInfo( $_POST['CajaxServerCodeHandler_function'] );
			
			if ($callingInfo === $this->functionInfo)	// if it's calling the same as I'm handleling
				$this->executeServerSideFunction (
							isset( $_POST['CajaxServerCodeHandler_parameters'] )?
								$_POST['CajaxServerCodeHandler_parameters'] : array()
						);
			
		}
			
	}
	
	
	
} // end :: CajaxServerCodeHandler [class]
?>