<?php
/*
 * A CajaxServerCodeHandler exibition
 * 
 * In this page, we use a dummy class for ilustrating this handler's use, manipulating instance methods
 * 
 * See text input's onkeyup event, and button's onpress event
 */


class Dummy {
	var $name;
	var $age;
	
	function Dummy($name, $age) {
		$this->name = $name;
		$this->age = $age;
	}
	
	function makeBirthday() {
		$this->age++;	// Here, we could save informations in database, for example...
		print "Congratulations! This is your birthday! Now, you're {$this->age} years old!!";
		return $this->age;
	}
	
	function changeName($name) {
		if ( strlen($name) < 2 ) {
			print "You can't have a name shorter than 2 letters!";
			return 0;
		}
				
		$this->name = $name;	// Again, we could change database informations, making data persistent... :)
		print "Your new name is $name";
		return 1;
	}
	
}


$MyInstance = new Dummy('Thiago F. Pappacena', 19);


    //////////////////////
   // Cajax processing //
  //////////////////////

require("../../../CajaxInterface.php");	// Require CajaxInterface

$Cajax = new CajaxInterface();

$MakeBirthdayHandler = new CajaxServerCodeHandler( 'MyInstance->makeBirthday', 'outputDIV' );
$ChangeNameHandler = new CajaxServerCodeHandler( 'MyInstance->changeName', 'outputDIV' );

$Cajax->addHandler( $MakeBirthdayHandler );
$Cajax->addHandler( $ChangeNameHandler );

$Cajax->handleAll();
?>

<html>
<head>

	<meta http-equiv="Content-Language" content="en" />
	<meta name="GENERATOR" content="PHPEclipse 1.0" />
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>CajaxServerCodeHandler Example - Manipulating methods</title>
	<style>
		.text {
			font-size: 12px;
			font-face: verdana;
		}
	</style>
<?=$Cajax->displayJSInterface();?>

</head>

<body bgcolor="#FFFFFF" text="#000000" link="#FF9966" vlink="#FF9966" alink="#FFCC99">
	
<div class="text">
Hi! <br/>

My name is <input type="text" name="name" value="<?=$MyInstance->name?>" onkeyup="Cajax.server.MyInstance.changeName(this.value);" class="text" />

<br />
<input type="button" value="Click here to make me older!" onclick="Cajax.server.MyInstance.makeBirthday();" class="text" />
</div>



<br /><br /><div id="outputDIV" class="text"></div>
	
</body>

</html>
  