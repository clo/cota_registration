<?php
function calculate($x, $y) {
	sleep(2);
	print "Server called || Where will go output?";
	return $x * $y;
}


require("../../../CajaxInterface.php");	// Require CajaxInterface

$Cajax = new CajaxInterface();	// Creates CajaxInterface
$Cajax->useCache(false);

$Handler = new CajaxServerCodeHandler('calculate', 'outputDIV');

$Cajax->addHandler($Handler);

$Cajax->handleAll();
?>
<html>
<head>
	<title>Server Code Handler example</title>
	<? $Cajax->displayJSInterface(); ?>
</head>


<body>

<div id="outputDIV"></div>

<input type="text" id="text" name=""><input type="button" value="*2" onclick='doSomeStupidThing()'>

<script>
	function doSomeStupidThing() {
		inputText = document.getElementById('text');
		
		if ( confirm('It will multiply the input content by 2.\nExecution will be delayed 2 seconds, so you can see the efects of overheads and stuff.\nContinue?') ) {
			result = Cajax.server.calculate( 2, inputText.value );
			alert('calculated!');
			
			inputText.value = result;
		}
	}
</script>

</body>


</html>