Cajax = new Object;
Cajax.server = new Object;
Cajax.includedFiles = new Array();

// Returns if the file was already included
Cajax.wasIncluded =	function (file) {
						inc = this.includedFiles;
						for(i=0 ; i<inc.length ; i++)
							if (inc[i] == file)
								return true;
						return false;
					};

// Returns if all files had been included
Cajax.allFilesIncluded =	function (files) {
								for(i=0 ; i<files.length ; i++)
									if ( !this.wasIncluded(files[i]) )
										return false;
								return true;
							};


// Returns a new XMLHTTPRequest object
Cajax.getNewRequester =	function (){
							try {
								Obj = new ActiveXObject("Msxml2.XMLHTTP");
							} catch (e) {
								try {
									Obj = new ActiveXObject("Microsoft.XMLHTTP");
								} catch (oc) {
									Obj = null;
								}
							}
							if(!Obj && XMLHttpRequest != undefined){	// If no Microsoft object
								Obj = new XMLHttpRequest();				// Use default one
							}
						
							return Obj;	// Return the object
						};

// The opened requisitions
Cajax.openedRequisitions = new Array();


// Do a requesition
Cajax.doRequest =	function (location, parms, method, returnFunction){

						async = true;
						
						if ( returnFunction == undefined )
							async = false;
							
						x = this.getNewRequester();	// Get a XMLHTTPRequest that works with user agent
						if (!x){					// Oops...
							alert("Could not create connection object."); return;
						}
					
						if (location.length == 0)
							location = document.location.href;
					
						method = method.toUpperCase();
					
						if (method == 'GET'){	// If sending through GET method, attach parms in URL and unset parms variable
							location = (location.indexOf('?') == -1)? location+ "?" +parms : location+ "&" +parms;
							parms = null;
						}

						// Prepare Requester
						x.open(method, location, async);	// Open requester object
					
						if (method == 'POST'){		// If sending through POST method, set the headers
							x.setRequestHeader("Method", "POST " + location + " HTTP/1.1");
							x.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
						}
					
					
						if (async) {			// If it's an assyncronous call,
						
							requesterID = Cajax.openedRequisitions.length;
							
							// What to do when get response from server?
							x.onreadystatechange = function (){
														if (x.readyState != 4)				// If not completed
															return;							// return
														returnFunction(x.responseText);		// Completed! Call resturnFunction passing the request returned text
														delete x;
														Cajax.openedRequisitions.splice(requesterID, 1);
													};
							x.send(parms);								// Send the request to server-side

							Cajax.openedRequisitions[requesterID] = x;
							return x;									// return the object
							
						}
						else {						// otherwise,
						
							x.send(parms);			// Send the request to server-side
						
							txt = x.responseText;	// Get response
							delete x;
							
							return txt;				// Return the response text (some browsers, like IE and Opera. cannot use the XMLHTTPRequest Object outside this escope after the end of sync call)
							
						}
					
						
					};

// Add an event to obj
function addEvent(obj, ev, fn){
	if (obj.attachEvent)
		obj.attachEvent('on'+ev, fn);
	else 
		obj.addEventListener(ev, fn, true);
}

// Gets an element by its ID
function cjxElem(s){
	return (document.getElementById)?document.getElementById(s):document.all[s];
}

// Prevent the default behavior of a event
function preventDefault(e) {
	if (e.preventDefault) e.preventDefault(); 
	e.returnValue = false;
}