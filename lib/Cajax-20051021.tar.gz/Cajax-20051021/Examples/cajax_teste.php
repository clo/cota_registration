<?php
/*
	##############################################################
	HERE, YOU PUT YOUR PROGRAM, FUNCTIONS, OBJECTS AND EVERYTHING
	##############################################################
*/


if (isset($_POST['formSent'])) {					// If the form was sent, do something and output results
	echo "<pre>";
	print_r($_POST);
	print "The form has been sent successfuly!";
	echo "</pre>";
	
	sleep(1);		// Just to see "wait" message :)
	
	exit;
}



/**
 * Dummy function for testing Cajax using a simple function
 */
function sayHello() {
	print "Hello, world";
}


/**
 * Dummy class for testing Cajax...
 */
class Talking {
	var $name;
	
	function Talking($name) {
		$this->name = $name;
	}
	
	function saySomething() {
		return "Good morning, man!";
	}
	
	function sayMyName() {
		$date = date('d/m/Y h:i:s');
		return "My name is $this->name and, in server, $date";
	}
	
	function saySomethingAndDate($parameter, $msg) {
		$date = date('h:i:s');
		return "($date::{$_SERVER['REMOTE_ADDR']})\n\t $msg? Ok, but what the hell is a {$parameter}?";
	}
	
	function speak($var, $msg) {
		$date = date('d/m/Y h:i:s');
		if (date('h') > 6 && date('h') < 12)
			$msg .= " (before lounch!)";
		elseif (date('h') < 18)
			$msg .= " (before dinner!)";
		else
			$msg .= " (that's night!)";
		return "Speaking $var at $date.\n{$msg}";
	}
	
	function doSomethingInDatabase($connection, $parameter) {
		// Do something with $connection and parameter
		return "I received [$connection, '$parameter'] and done something in database with it";
	}
	
} // end of class

// Another class
// Makes JavaScript to fill select box with places from a $country
// (just an exemple... you may need to user database and stuff...)
class Places {
	
	function getPlacesFromCountry ($country) {
		if ($country == 1) {
			
			return "
				selectPlaces = document.getElementById('places');
				for(i=selectPlaces.length-1 ; i>=0 ; i--)
					selectPlaces[i] = null;
	
				selectPlaces[ selectPlaces.length ] = new Option;
				selectPlaces[ selectPlaces.length -1 ].value = '1';
				selectPlaces[ selectPlaces.length -1 ].text = 'Rio de Janeiro';
	
				selectPlaces[ selectPlaces.length ] = new Option;
				selectPlaces[ selectPlaces.length -1 ].value = '2';
				selectPlaces[ selectPlaces.length -1 ].text = 'S�o Paulo';
			";
			
		}
		elseif($country == 2) {
		
			return "
				selectPlaces = document.getElementById('places');
	
				for(i=selectPlaces.length-1 ; i>=0 ; i--)
					selectPlaces[i] = null;
	
				selectPlaces[ selectPlaces.length ] = new Option;
				selectPlaces[ selectPlaces.length -1 ].value = '2';
				selectPlaces[ selectPlaces.length -1 ].text = 'Lisboa';
	
				selectPlaces[ selectPlaces.length ] = new Option;
				selectPlaces[ selectPlaces.length -1 ].value = '3';
				selectPlaces[ selectPlaces.length -1 ].text = 'Porto';
			";
			
		}
		else {
			return "
				selectPlaces = document.getElementById('places');
				for(i=selectPlaces.length-1 ; i>=0 ; i--)
					selectPlaces[i] = null;";
		}
		
	}
	
}


class Suggestion {
	
	function getSuggestions($string) {
		if (strlen($string) < 2)
			return array();
		$string = ucfirst($string);
		$values =  array(
				'Thiago',
				'Rafael',
				'Carlos',
				'Anderson',
				'Maur�cio',
				'Carol',
				'Roberto',
				'Aline',
				'Alimentação',
				'Alemanha',
				'Acorrentar',
				'Bárbara',
				'Los Hermanos',
				'Engenheiros do Hawaii',
				'Nirvana',
				'Xuxa',
				'Taís',
				'Isabela',
				'Vanessa',
				'Chopp',
				'Kombi',
				'Alambrado',
				'Caixa',
				'Celular',
				'CPM22'
			);
			
		$ret = array();
		foreach($values as $k=>$v)
			if ( substr($v, 0, strlen($string)) == $string)
				$ret[] = $v;
				
		return $ret;
	}
	
	
	function getURL($string) {
		
		$values = array (
				'www.google.com.br',
				'www.control-lab.com.br',
				'www.yahoo.com',
				'www.aol.com.br',
				'www.cade.com.br',
				'www.brasilenergia.com.br',
				'www.orkut.com',
				'www.getfirefox.com',
				'www.kernel.org',
				'www.arroba.ponto.traco.ponto.pt.com.net.tv.br',
				'www.br-linux.org',
				'www.gmail.com',
				'www.vivaolinux.com.br',
				'www.linux.org',
				'www.slackware.com',
				'www.debian.org'
			);
			
		$ret = array();
		foreach($values as $k=>$v)
			if ( substr($v, 0, strlen($string)) == $string)
				$ret[] = $v;
		sort($ret);
		return $ret;
	}
	
}


function returnFuckinArray($id) {
	if ($id == 1)
		return array (
					'Nohting',
					'Else',
					'Matters'
				);
	else
		return array (
					'I',
					'Love',
					'Chocolate'
				);
}

$connection = "Resource ID#666";	// Connect to database
$People = new Talking('Test: Talking Object');	// New Object
// creates millions of other objects...
// ... some other initializations




/*
	##########################################################################################
	HERE, WE START USING SOME ABSTRACTION BETWEEN YOUR PHP PROGRAM AND YOU HTML/JAVASCRIPT GUI
	##########################################################################################
*/


$begin = getmicrotime();			// Get atual time for measuring the time wasted processing Cajax

require('../CajaxInterface.php');

	// *** Create some event handlers... *** //
// On copy_button click, call javascript:copyText(). Inside this function, a call for server side Talking::saySomethingAndDate($People, {clientsideParameter}) will be done and the return goes to javascript:returnFunction(returnText)
$CopyEvent = new CajaxEventHandler( /*Object*/ 'copy_button', /*Event*/ 'onclick', /*Server Action*/ 'Talking::saySomethingAndDate', /*JavaScript return function*/ 'returnFunction', /*JavaScript callback function*/ 'copyText', /*Server side parameters*/ array($People->name));

// On helloButton mouse over, call server-side function sayHello() using default behavior (alert the output) and passing no parameters
$SayHelloMouseOver = new CajaxEventHandler('helloButton', 'mouseover', 'sayHello');

// On doSomethingDBLink object click, call People->doSomethingInDatabase($connection) through javascript:doSomethingInDb(), returning the result of request to javascript:doneSomethingInDb
$DBDoSomething = new CajaxEventHandler('doSomethingDBLink', 'click', 'People->doSomethingInDatabase', 'doneSomethingInDb', 'doSomethingInDb', array($connection));

// When change country, get places from there (server will say in javascript language. So, I wanna 'eval' it)
$ChangeCountry = new CajaxEventHandler('country', 'onchange', 'Places::getPlacesFromCountry', 'eval', 'getPlacesFromServer');



	// *** ... and a form handler *** //
// Form handler is easyer... just say the form ID and the return function.
$FormHandler = new CajaxFormHandler( /*Form ID*/ 'testForm', /*Return JS function*/ 'getReturnedSubmit');


$Suggester = new CajaxSuggestHandler('suggest', 'Suggestion::getSuggestions', 'suggestBox');
$SuggesterURL = new CajaxSuggestHandler('suggest_url', 'Suggestion::getURL', 'suggestBox', 'suggestBoxSelected');

$SelectChangeHandler = new CajaxSelectIntegrationHandler('sourceSelect', 'destinationSelect', 'returnFuckinArray');



	// *** Create the interface to handle the handlers ;) *** //
$Cajax = new CajaxInterface();
/*$Cajax->setCacheDir("dev/thiago/control/testes/jsObjects/Cajax/Examples/cajaxCache");
$Cajax->useCache(true);*/

$Cajax->addHandler($CopyEvent);
$Cajax->addHandler($SayHelloMouseOver);
$Cajax->addHandler($DBDoSomething);
$Cajax->addHandler($ChangeCountry);

$Cajax->addHandler($Suggester);
$Cajax->addHandler($SuggesterURL);

$Cajax->addHandler($FormHandler);

$Cajax->addHandler($SelectChangeHandler);



// Begin the listener for the events and forms submits.
// When one of the event occur, the whole script will be executed until this method call.
// (Forms submit will execute the entire ACTION form script, then return the output through javaScript return function)
// handleAll() will check for Cajax call for events. If it's a Cajax request, then the requested resource will be fired,
// and the script will exit. After that, the method will output JavaScript to handle events and forms.
// Keep in mind that:
//	- Output until now will be returned to your XMLHttpRequest on event occur 
//			(so, don't 'print' anything before handleAll() if you're using event handlers)
//	- All processing done until now WILL be done again on XMLHttpRequest on event occur
// 	- this method will also print some javascript after handling all javascript events
$Cajax->handleAll();

$end = getmicrotime();
$totalTime = $end - $begin;		// How many time was spended processing Cajax?


// Now, you display the page... 
// or maybe some template system... I prefere Smarty... ;)
?>
<!-- BEGIN OF HTML OUTPUT -->
<html>

<head>
	<?$Cajax->displayJSInterface()?>
	
</head>

<style>
	.suggestBox {
		padding: 0px;
		spacing: 0px;
		/* border: 1px solid black; */
		font-size: 11px;
		color: #0F0FB3;
		font-face: arial;
		background-color: #FAFAFA;
	}
	
	.suggestBoxSelected {
		padding: 0px;
		spacing: 0px;
		font-size: 11px;
		color: #0F0BF3;
		font-face: arial;
		background-color: #FBF0F0;		
	}
</style>


<body>
<script>alert('Cajax execution time: <?printf("%0.5f", $totalTime)?> s');</script>
	<!-- BEGIN OF EVENT HANDLER -->
	
	<hr>
	<div align="center" style="font-family: arial; font-size: 17px; font-weight: bold">Click event: send a text to server and copy the response to textarea</div>
	<hr>
	
<input type="text" name="textBox" id="textBox" value="nada" size="20" maxlength="40"/>
<input type="button" value="->" id="copy_button">
<textarea id='anotherBox' cols="70" rows="10" disabled></textarea><input type="button" onclick="document.getElementById('anotherBox').value = ''" value="Clear">





<br><br><br><br>
	<hr>
	<div align="center" style="font-family: arial; font-size: 17px; font-weight: bold">Mouse Over event: get a text from the server and alert it</div>
	<hr>
<center><input type="button" name="helloButton" id="helloButton" value="Say hello"/></center>





<br><br><br><br>
	<hr>
	<div align="center" style="font-family: arial; font-size: 17px; font-weight: bold">Click event: pass a server-side resource and a client-side text to method</div>
	<hr>
<input type="text" name="username" id="username" value="hum? Username?"/><a href="#" id="doSomethingDBLink">Click here to do something in database</a>  





<br><br><br><br>
	<hr>
	<div align="center" style="font-family: arial; font-size: 17px; font-weight: bold">Select change event: select a country and fill select box with it's places</div>
	<hr>
	  
<script>
	function getPlacesFromServer() {
		inp = document.getElementById('country');
		countryID = inp[ document.getElementById('country').selectedIndex ].value
		inp.Cajax.onchange(countryID, <?=$ChangeCountry->get('jsReturnFunctionName')?>);
	}
</script>
<select name="country" id="country">
	<option value=""></option>
	<option value="1">Brasil</option>
	<option value="2">Portugal</option>
</select>

<select name="places" id="places">

</select>


<br><br><br><br>
	<hr>
	<div align="center" style="font-family: arial; font-size: 17px; font-weight: bold">SelectIntegration: null</div>
	<hr>
<select name="" id="sourceSelect">
	<option value="1">Nothing</option>
	<option value="2">Chocolate</option>
</select>

<select name="" id="destinationSelect">

</select>
	
	


  
<script>
/**
 * Return from $DBDoSomething event
 **/
function doneSomethingInDb(returnValue) {
	if (returnValue)
		alert('Something has been done successfullyyyy in database\n(server response "' + returnValue + '")');
	else
		alert('Error while trying to do something in database')
}


/**
 * Trigger function for $DBDoSomething event
 **/
function doSomethingInDb() {
	inp = document.getElementById('username');
	link = document.getElementById('doSomethingDBLink');
	link.Cajax.onclick(inp.value, doneSomethingInDb);
}


/**
 * Return from $CopyEvent event
 **/
function returnFunction(ret) {
	document.getElementById('anotherBox').value += ret+"\n\n";
}


/**
 * Trigger function for $CopyEvent event
 **/
function copyText(event) {
	textBox = document.getElementById('textBox');
	inp = document.getElementById('copy_button');
	inp.Cajax.onclick(textBox.value, returnFunction);
}


</script>
	<!-- END OF EVENT HANDLER -->
	
	
	
	
	
	
	<!-- SUGGEST HANDLER -->
<br><br><br><br>
	<hr>
	<div align="center" style="font-family: arial; font-size: 17px; font-weight: bold">Suggest exemple</div>
	<hr>
	
<input type="text" id="suggest" value="">

<br><br><br><br>
	<hr>
	<div align="center" style="font-family: arial; font-size: 17px; font-weight: bold">Another suggest exemple</div>
	<hr>

<form>	
Type 'www' where: <input type="text" id="suggest_url" value="" size="35">
</form>
<script>
	//alert(cjxElem('suggest'));
</script>
	<!-- END OF SUGGEST HANDLER -->









<br><br><br><br>
	<hr>
	<div align="center" style="font-family: arial; font-size: 17px; font-weight: bold">Form handler: Submit a form and display the response in a DIV element</div>
	<hr>


	<!-- BEGIN OF FORM HANDLER -->
<script>

	  ////////////////////////////////////////////////////////////////////////////////
	 // Function definitions for Sending and receiving form XMLHttpRequest submits //
	////////////////////////////////////////////////////////////////////////////////


	/**
	 * Function to get the form submit answer
	 **/
	function getReturnedSubmit(text) {
		document.getElementById('form_answer').innerHTML = text;
	}
	
	/**
	 * Function to be called to submit the form
	 **/
	function validateForm() {
		// Here you may want to do some validations
		form = document.getElementById('testForm');
		
		if (form.testeBox.value.length == 0) {
			alert('Please, write something to send to server...');
			form.testeBox.focus();
			return false;
		}
		
		// Display a "wait" message, so the user don't get furious and start a nervous and sequencial "clicking session" on submit button... :P
		document.getElementById('form_answer').innerHTML = 'Please wait...';
		
		return true;
	}
</script>


<table align="center">
	<tr>
		<td><div id="form_answer"></div></td>
	</tr>
</table>

<table style="border: 1px solid black" align="center">
	<tr>
		<td>
			<form onsubmit="return validateForm();" id="testForm" name="testForm" action="<?=$_SERVER['PHP_SELF']?>" method="POST">
			<input type="hidden" name="formSent" value="1">
				<input type="checkbox" name="color[]" value="red"> Red<br>
				<input type="checkbox" name="color[]" value="green"> Green<br>
				<input type="checkbox" name="color[]" value="blue"> Blue<br><br>
				
				<input type="radio" name="country" value="Brasil"> Brasil<br>
				<input type="radio" name="country" value="Other"> Other<br><br>
				
				<select name="object[]" multiple>
					<option value="table">Table</option>
					<option value="phone">Telephone</option>
					<option value="computer">Computer</option>
				</select><br><br>
				
				<select name="smoking">
					<option value="no">No</option>
					<option value="yes">Yes</option>
				</select>
			
				<input type="text" name="testeBox" value="Send form, please!"><input type="submit" value="Send!">
			
			</form>
		</td>
	</tr>
</table>

	<!-- END OF FORM HANDLER -->
	
	
	
<table id="treco" style="background-color: blue;" cellpadding="0">

</table>
	
	
	
<script>

/*tbl = document.getElementById('treco');

str = "";
for(i in tbl)
	str += "tbl["+ i +"] = "+ tbl[i] + "\n";
alert(str.indexOf('a')); */

alert( document.getElementById('copy_button').Cajax );
</script>

</body>
</html>
<!-- END OF HTML OUTPUT -->
<?
function getmicrotime() 
{ 
    list($usec, $sec) = explode(" ", microtime()); 
    return ((float)$usec + (float)$sec); 
} 
?>