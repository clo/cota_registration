<?php
require("../CajaxInterface.php");

$Cajax = new CajaxInterface();	// New cajax interface


$files = CajaxInterface::getExamplesFiles( CAJAX_ROOT );	// Get examples files inside Cajax directory tree
$Examples = array();

foreach($files as $k=>$v) {
	
	$Examples[$k] = new Example($v);		// Creates a new Example object (class defined at the end of script)
	// Add a handler for click on "source" link
	$Cajax->addHandler(
			new CajaxEventHandler("source_$k", "onclick", "Examples[$k]->highlightCode", 'function (response) { document.getElementById("sourceCode").innerHTML = response; }')
		);

}

//$Cajax->useCache(false);
$Cajax->handleAll();




	// Colors for table //
$lastBaseDir = "";
$basedirIndex = 0;
$i = 0;
$randomColors = array (
					array('#FBFBE4', '#F1F1E2'),
					array('#F5F5F5', '#FDFDFD')
				);
?>
  
<html>
<head>

	<meta http-equiv="Content-Language" content="en" />
	<meta name="GENERATOR" content="PHPEclipse 1.0" />
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	
	<title>Cajax Examples</title>
	
	<style>
		.normal {
			font-face: arial;
			font-size: 11px;
			color: #3F3F3F;
		}
		
		.bold {
			font-face: arial;
			font-size: 11px;
			color: #3F3F3F;
			font-weight: bold;
		}
	</style>
	
	<!-- JAVASCRIPTS FOR THE PAGE -->
	<? $Cajax->displayJSInterface() ?>
	<script language="JavaScript" type="text/javascript" src="dragAndDrop.js"></script>
	<script>
		function showHideBrowser() {
			browser = document.getElementById('browser');
			browser.style.display = (browser.style.display == 'none')? 'block' : 'none';
		}
	</script>
	<!-- END :: JAVASCRIPTS FOR THE PAGE -->	
	
</head>


<body bgcolor="#FFFFFF" text="#000000" link="#FF9966" vlink="#FF9966" alink="#FFCC99">


<!-- LINKS -->
<table style="padding: 0px; spacing: 0px;" class="normal">
	<tr>
		<td class="bold" style="background-color: #F0F0FF; font-size: 12px; text-align: center;" colspan="3">Examples</td>
	</tr>
	
<? foreach($Examples as $k=>$Example) { ?>
<? 
	if ( ($x = $Example->get('basedir')) != $lastBaseDir ) {
		$lastBaseDir = $x;
		$basedirIndex++;
	}
?>
	
	<tr bgcolor="<?=$randomColors[ $basedirIndex%2 ][ $i++%2 ]?>">
	
		<td id="details_<?=$k?>"><?=$Example->get('basedir') .'/'. $Example->get('fileName')?></td>
		<td> 
			[<a href="<?=$Example->get('link')?>" target="example_link" class="bold">Open</a>
			| <a href="javascript:void(0)" id="source_<?=$k?>" class="bold">Source code</a>]
		</td>
		
	</tr>
	
<? } ?>

	<tr>
		<td height="15" colspan="3"><hr></td>
	</tr>

</table>


<!-- Page browser -->
<div align="center" style="width: 100%;">

	<div style="width: 50%; text-align: center; border: 1px solid black; background-color: white;" id="janela">
	
		<!-- Title bar -->
		<div style="background-color: #F0F0FF; border-bottom: 1px solid black;" class="bold">
			Browser 
			[<a href="javascript:void(0)" class="normal" onclick="showHideBrowser()">show/hide</a> | 
			<a href="javascript:void(0)" class="normal" onclick="setDraggable(document.getElementById('janela'))">unlock</a>]
		
		</div>
		
		<!-- Window body :P -->
		<iframe name="example_link" id="browser" src="" frameborder="0" style="border: 0px; width: 100%;"></iframe>
	</div>
	
</div>
<!-- END :: Page browser -->



<!-- Source div -->
<div id="sourceCode" style="width: 100%">

</div>
<!-- END :: Source div -->


</body>
</html>
<?
class Example {
	
	var $fileName;
	var $link;
	var $basedir;
	
	function Example($file) {
		
		$this->serverFile	= $file;
		$this->fileName		= basename($file);
		$this->basedir		= str_replace( CAJAX_ROOT, '', dirname($file) );
		$this->link			= "../{$this->basedir}/{$this->fileName}";
	
	} // end :: constructor
	
	function highlightCode() {
		highlight_file($this->serverFile);
	} // end :: highlightCode
	
	function get($attribute) {
		return $this->$attribute;
	}
	
} // end :: Example
?>
  